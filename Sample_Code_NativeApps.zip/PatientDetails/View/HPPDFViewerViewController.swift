//
//  HPPDFViewerViewController.swift
//  MAPS
//
//  Created by shubhamfunde on 06/02/23.
//

import UIKit
import WebKit

class HPPDFViewerViewController: BaseViewController {
    
    @IBOutlet weak var titleImageView: UIImageView!
    @IBOutlet weak var titleLbl: UILabel!
    @IBOutlet weak var webView: WKWebView!
    
    lazy var viewModel: PatientDetailsPopUpViewModel = {
        let obj = PatientDetailsPopUpViewModel(service: UserService(), hgservice: HGService())
        self.baseVwModel = obj
        return obj
    }()
    
    var hgDocID: String?
    var isHP: Bool?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        if (isHP ?? false) == false {
            titleImageView.image = UIImage(named: AssetImages.AnesRec_New)
            titleLbl.text = TitleConstant.anesthesiaRecord
        }
        viewModel.getPDFUrl(docId: hgDocID ?? "")
        
        viewModel.reloadListViewClosure = { [weak self]() in
            DispatchQueue.main.async {
                self?.webView.load(self?.viewModel.dataPDF ?? Data(), mimeType: Keys.contentType.pdf, characterEncodingName: "", baseURL: NSURL() as URL)
            }
        }
    }
    
    @IBAction func cancelDidClicked(_ sender: UIButton) {
        self.dismiss(animated: true)
    }
}
