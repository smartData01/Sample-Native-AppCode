//
//  PatientDetailsViewController.swift
//  MAPS
//
//  Created by shubhamfunde on 02/05/22.
//

import UIKit
import MXSegmentedControl
import SDWebImage
import iOSDropDown

struct Section {
    var name: String
    var items: [String]
    var collapsed: Bool
    
    init(name: String, items: [String], collapsed: Bool = true) {
        self.name = name
        self.items = items
        self.collapsed = collapsed
    }
}

class PatientDetailsViewController: BaseViewController, reloadDelegate, DenyPopOverDelegate {
    
    @IBOutlet weak var patientImageView: UIImageView!
    @IBOutlet weak var patientNameLbl: UILabel!
    @IBOutlet weak var dobLbl: UILabel!
    @IBOutlet weak var socialSecNoLbl: UILabel!
    @IBOutlet weak var contactNoLbl: UILabel!
    @IBOutlet weak var emailLbl: UILabel!
    @IBOutlet weak var addressLbl: UILabel!
//    @IBOutlet weak var segmentControl: MXSegmentedControl!
//    @IBOutlet weak var scrollViewHeight: NSLayoutConstraint!
    @IBOutlet weak var weightLbl: UILabel!
    @IBOutlet weak var heightLbl: UILabel!
//    @IBOutlet weak var segmantScrollView: UIScrollView!
    @IBOutlet weak var bottomStackView: UIStackView! //55
    @IBOutlet var bottomStackHeight: NSLayoutConstraint!
//    @IBOutlet weak var activeSwitch: UISwitch!
//    @IBOutlet weak var activeLbl: UILabel!
    @IBOutlet weak var bmiLbl: UILabel!
//    @IBOutlet weak var segmentPatient: MXSegmentedControl!
    
    @IBOutlet weak var AnesthesiaRecordBtn: RoundedButton!
    @IBOutlet weak var requestRecordBtn: RoundedButton!
    @IBOutlet weak var prescriptionBtn: RoundedButton!
    @IBOutlet weak var clearanceView: RoundedView!
    @IBOutlet weak var appointmentView: RoundedView!
    @IBOutlet var appointmentBottomConstraint: NSLayoutConstraint! //30
    @IBOutlet var appointmentStackHeight: NSLayoutConstraint! //50
    @IBOutlet var stackBottomConstraint: NSLayoutConstraint! //20
    @IBOutlet weak var appointmentStackView: UIStackView!
    @IBOutlet weak var appointmentClearanceSV: UIStackView!
    @IBOutlet weak var asaDD: DropDown!
    @IBOutlet weak var clearUpDD: DropDown!
    @IBOutlet weak var rejectBtn: UIButton!
    @IBOutlet weak var acceptBtn: UIButton!
    @IBOutlet weak var cancelBtn: UIButton!
    @IBOutlet weak var appointmentDateLbl: UILabel!
    
    @IBOutlet weak var medicalStackView: UIStackView!
    @IBOutlet weak var hgStackView: UIStackView!
    
    @IBOutlet weak var requestedMrView: UIView!
    
    var isStackHidden = false
    var dateFormatter = DateFormatter()
    var dateFormatter1 = DateFormatter()
    var patientId : Int?
    var appointmentId : Int?
    var ssnBtnBool = true
//    var isActive = false
    var isPatient = true
//    var segmentPos = 0
    var appointmentDate : String?
    var clinicName : String?
    let storyBoard = UIStoryboard(name: StoryBoard.common, bundle: nil)
    
    lazy var viewModel: PatientDetailsViewModel = {
        let obj = PatientDetailsViewModel(service: UserService(), hgservice: HGService())
        self.baseVwModel = obj
        return obj
    }()
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        viewModel.getPatientDetails(patientID: self.patientId ?? 0, appointmentId: self.appointmentId ?? 0)
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        if appointmentId == nil {
            bottomStackView.isHidden = true
            bottomStackView.heightAnchor.constraint(equalToConstant: 0).isActive = true
            appointmentClearanceSV.heightAnchor.constraint(equalToConstant: 0).isActive = true
            appointmentClearanceSV.isHidden = true
            
//            appointmentBottomConstraint.constant = 0
        }
        requestedMrView.isHidden = true
        
        let ddPrefix = UIView()
        ddPrefix.widthAnchor.constraint(equalToConstant: 15).isActive = true
        asaDD.leftView = ddPrefix
        asaDD.leftViewMode = .always
        let clearddPrefix = UIView()
        clearddPrefix.widthAnchor.constraint(equalToConstant: 15).isActive = true
        clearUpDD.leftView = clearddPrefix
        clearUpDD.leftViewMode = .always
        
        AnesthesiaRecordBtn.isHidden = true
        prescriptionBtn.isHidden = true
//        appointmentClearanceSV.isHidden = true
        dateFormatter.dateFormat = DatePickerFormat.yyyy_MM_dd_T_HH_mm_ss
        dateFormatter1.dateFormat = DatePickerFormat.MM_dd_yyyy
//        segmentControl.append(title: "Reported Conditions")
//        segmentControl.append(title: TitleConstant.medication.capitalized)
//        segmentControl.append(title: "Allergies")
//        segmentControl.append(title: "Surgical History")
//        segmentControl.append(title: "Anesthesia Hx")
//        self.activeLbl.isHidden = true
//        self.activeSwitch.isHidden = true
//        segmentPatient.append(title: "Forms")
//        segmentPatient.append(title: "Emergency Contact")
//        segmentPatient.append(title: "Treating Physicians")
//        segmentPatient.append(title: "Day of surgery driver/caretake")
//
//        segmentPatient.font = UIFont(name: FontConstant.SFProDisplayBold, size: iPad ? 16 : 12) ?? UIFont.systemFont(ofSize: iPad ? 16 : 12, weight: .bold)
//        segmentControl.font = UIFont(name: FontConstant.SFProDisplayBold, size: iPad ? 16 : 12) ?? UIFont.systemFont(ofSize: iPad ? 16 : 12, weight: .bold)
        hgStackView.isHidden = isPatient
        setUpClosure()
        
//        NotificationCenter.default.addObserver(self, selector: #selector(approveBtn(_:)), name: NSNotification.Name(NotiCenterConstant.approveBtn), object: nil)
        acceptBtn.isHidden = true
        rejectBtn.isHidden = true
        cancelBtn.isHidden = true
    }
    
    @IBAction func appointmentBtnClicked(_ sender: UIButton) {
        let hiddenVal = !isStackHidden
        isStackHidden = hiddenVal
        appointmentStackHeight.constant = isStackHidden ? 0 : 50
        stackBottomConstraint.constant = isStackHidden ? 0 : 20
        appointmentStackView.isHidden = isStackHidden
    }
    
//    @objc func approveBtn(_ notification: Notification) {
//        self.viewModel.approveDocuments(appointmentId: self.appointmentId ?? 0, anesthesiologistId: getUesrInfo()?.id ?? 0)
//    }
    
    @IBAction func cancelBtnClicked(_ sender: UIButton) {
        let storyboard = UIStoryboard(name: StoryBoard.main, bundle: nil)
        let vc = storyboard.instantiateViewController(withIdentifier: VCIdentifiers.CancelCasePopUpViewController) as! CancelCasePopUpViewController
        vc.modalPresentationStyle = .overFullScreen
        vc.modalTransitionStyle = .crossDissolve
        vc.delegate = self
        vc.clinicId = viewModel.patientDetails?.clinicId
        vc.appotId = appointmentId
        present(vc, animated: true)
    }
    
    @IBAction func rejectBtnClicked(_ sender: UIButton) {
        let storyboard = UIStoryboard(name: StoryBoard.main, bundle: nil)
        let vc = storyboard.instantiateViewController(withIdentifier: VCIdentifiers.DenyPopUpViewController) as! DenyPopUpViewController
        vc.modalPresentationStyle = .overFullScreen
        vc.modalTransitionStyle = .crossDissolve
        self.tabBarController?.tabBar.isHidden = true
        vc.delegate = self
        vc.appointmentId = appointmentId
        present(vc, animated: true)
    }
    
    @IBAction func acceptBtnClicked(_ sender: UIButton) {
        if asaDD.text?.trimmingCharacters(in: .whitespaces) == "" || clearUpDD.text?.trimmingCharacters(in: .whitespaces) == "" {
            if asaDD.text?.trimmingCharacters(in: .whitespaces) == "" {
                asaDD.borderColor = .red
            }
            if clearUpDD.text?.trimmingCharacters(in: .whitespaces) == "" {
                clearUpDD.borderColor = .red
            }
            return
        }
        
        viewModel.updateAppointmentStatus(appointmentId: appointmentId ?? 0, isApproved: true, reason: "", newDate: "", newStartTime: "", newEndTime: "") { status in
            let storyboard = UIStoryboard(name: StoryBoard.main, bundle: nil)
            let vc = storyboard.instantiateViewController(withIdentifier: VCIdentifiers.AlertViewController) as! AlertViewController
            vc.alert = .single
            vc.image = self.successImage
            vc.message = MessagesConstant.appointAcceptedMessage
            vc.modalPresentationStyle = .overFullScreen
            vc.modalTransitionStyle = .crossDissolve
            vc.didClicked = {
                self.viewModel.getPatientDetails(patientID: self.patientId ?? 0, appointmentId: self.appointmentId ?? 0)
            }
            self.present(vc, animated: true)
        }
    }
    
    func setUpClosure() {
//        viewModel.redirectControllerClosure = { [weak self] () in
//            DispatchQueue.main.async {
//                switch self?.segmentPos {
//                case 0: (self?.isPatient ?? true) ? self?.viewModel.getOtherPatient(patientId: self?.patientId ?? 0, appId: self?.appointmentId ?? 0) : self?.viewModel.getSummaryHG(HGID: self?.viewModel.id ?? "")
//                case 1: (self?.isPatient ?? true) ? self?.viewModel.getMedicationPatient(patientId: self?.patientId ?? 0, appId: self?.appointmentId ?? 0) : self?.viewModel.getVitalSignsHG(HGID: self?.viewModel.id ?? "")
//                case 2: (self?.isPatient ?? true) ? self?.viewModel.getAllergiesPatient(patientId: self?.patientId ?? 0, appId: self?.appointmentId ?? 0) : self?.viewModel.getLabsHG(HGID: self?.viewModel.id ?? "")
//                case 3: (self?.isPatient ?? true) ? self?.viewModel.getSurgicalPatient(patientId: self?.patientId ?? 0, appId: self?.appointmentId ?? 0) : self?.viewModel.getMedicationHG(HGID: self?.viewModel.id ?? "")
//                case 4: (self?.isPatient ?? true) ? self?.viewModel.getSummaryPatient(patientId: self?.patientId ?? 0, appId: self?.appointmentId ?? 0) : self?.viewModel.getAllergyHG(HGID: self?.viewModel.id ?? "")
//                default: break
//                }
//            }
//        }
        
        viewModel.reloadListViewClosure = { [weak self] () in
            DispatchQueue.main.async {
                self?.setUpUI()
                let patient = self?.viewModel.patientDetails
                let date = self?.dateFormatter.date(from: patient?.dob ?? "")
                let dateFormatter2 = DateFormatter()
                dateFormatter2.dateFormat = DatePickerFormat.yyyy_MM_dd
                if let appointmentId = self?.appointmentId, appointmentId != 0 {
                    self?.viewModel.getSubmittedDocs(appId: appointmentId, completion: { _ in
                        self?.requestedMrView.isHidden = (self?.viewModel.submittedDocs?.count ?? 0) == 0
                    })
                }
                if let id = patient?.hgId?.trimmingCharacters(in: .whitespaces), id != "" {
                    self?.viewModel.callOAuth(HGID: id)
                } else {
                    self?.viewModel.searchPatient(firstName: Utility.getDecryptString(dataString: patient?.firstname ?? ""), lastName: Utility.getDecryptString(dataString: patient?.lastname ?? ""), address: Utility.getDecryptString(dataString: patient?.address1 ?? ""), dob: dateFormatter2.string(from: date ?? Date()), gender: patient?.gender?.lowercased() ?? "", city: Utility.getDecryptString(dataString: patient?.city ?? ""), state: Utility.getDecryptString(dataString: patient?.state ?? ""), zipCode: Utility.getDecryptString(dataString: patient?.zipcode ?? ""))
                }
            }
        }
    }
    
    // MARK: - Setup UI
    func setUpUI() {
        appointmentClearanceSV.isHidden = false
        let patient = self.viewModel.patientDetails
        if let url = URL(string: patient?.imagePath ?? "") {
            patientImageView.sd_setImage(with: url, placeholderImage: UIImage(named: AssetImages.Dummy_Profile), options: .scaleDownLargeImages, completed: nil)
            patientImageView.sd_imageTransition = .fade
        }
        let name = Utility.getDecryptString(dataString: patient?.firstname ?? "").capitalized + " " + Utility.getDecryptString(dataString: patient?.lastname ?? "").capitalized
        patientNameLbl.text = name
        if let date = dateFormatter.date(from: patient?.dob ?? "") {
            let dob = dateFormatter1.string(from: date)
            dobLbl.text = dob
        }
        let ssn = Utility.getDecryptString(dataString: patient?.ssn ?? "")
        if  ssn.count > 8 {
            let start = ssn.index(ssn.startIndex, offsetBy: 0)
            let end = ssn.index(ssn.startIndex, offsetBy: 4)
            socialSecNoLbl.text = ssn.replacingCharacters(in: start...end, with: "xxxxx")
        }
        contactNoLbl.text = Utility.getDecryptString(dataString: patient?.contactno ?? "")
        emailLbl.text = Utility.getDecryptString(dataString: patient?.email ?? "")
        addressLbl.text = Utility.getDecryptString(dataString: patient?.address1 ?? "") + ", " + Utility.getDecryptString(dataString: patient?.city ?? "") + ", " + Utility.getDecryptString(dataString: patient?.state ?? "") + ", " + Utility.getDecryptString(dataString: patient?.zipcode ?? "")
        if let weight = Float(patient?.patientWeightInLbs ?? "0.0"), let feet = patient?.patientHeightFeet, let inch = patient?.patientHeightInch {
            
            weightLbl.text = ("W : " + String(format: "%.0f", weight) + " lbs")
            heightLbl.text = "H : " + "\(feet)'" + "\(inch)\""
            
            let bmi = Float(patient?.patientWeightInKg ?? "0.0")! / ((Float(patient?.patientHeightInCm ?? "100.0")! / 100.0) * (Float(patient?.patientHeightInCm ?? "100.0")! / 100.0))
            bmiLbl.text = "BMI : " + String(format: "%.1f", bmi)
        }
        AnesthesiaRecordBtn.isHidden = false
        prescriptionBtn.isHidden = false
        
        if patient?.isDraftSaved == true {
            requestRecordBtn.setImage(UIImage(named: AssetImages.Pulse), for: .normal)
        } else {
            requestRecordBtn.setImage(nil, for: .normal)
        }
        
        switch patient?.status {
        case 0:// Pending
            acceptBtn.isHidden = false
            rejectBtn.isHidden = false
            cancelBtn.isHidden = true
            AnesthesiaRecordBtn.isHidden = true
            prescriptionBtn.isHidden = true
        case 1:// Accepted
            cancelBtn.isHidden = false
            rejectBtn.isHidden = true
            acceptBtn.isHidden = true
        case 2:// Rejected
            cancelBtn.isHidden = true
            rejectBtn.isHidden = true
            acceptBtn.isHidden = true
            bottomStackView.isHidden = true
            bottomStackView.heightAnchor.constraint(equalToConstant: 0).isActive = true
            clearanceView.isHidden = true
        case 3:// Cancelled
            cancelBtn.isHidden = true
            rejectBtn.isHidden = true
            acceptBtn.isHidden = true
            bottomStackView.isHidden = true
            bottomStackView.heightAnchor.constraint(equalToConstant: 0).isActive = true
            clearanceView.isHidden = true
//            appointmentClearanceSV.heightAnchor.constraint(equalToConstant: 0).isActive = true
//            appointmentClearanceSV.isHidden = true
//            appointmentBottomConstraint.constant = 0
        default:
            cancelBtn.isHidden = true
            acceptBtn.isHidden = true
            rejectBtn.isHidden = true
            bottomStackView.isHidden = true
            bottomStackView.heightAnchor.constraint(equalToConstant: 0).isActive = true
            appointmentClearanceSV.heightAnchor.constraint(equalToConstant: 0).isActive = true
            appointmentClearanceSV.isHidden = true
            appointmentBottomConstraint.constant = 0
        }
        if let appDate = patient?.appointment_Date, let startTime = patient?.appointment_From, let endTime = patient?.appointment_To {
            let dateFormatter = DateFormatter()
            dateFormatter.dateFormat = DatePickerFormat.dd_MM_yyyy
            var appInfo = ""
            appInfo.append(self.dateFormatter1.string(from: dateFormatter.date(from: appDate)!))
            appInfo.append("  (\(startTime) - \(endTime))")
            if patient?.status == 3 || patient?.status == 2 {
                appInfo.append(patient?.status == 3 ? " (Cancelled)" : " (Denied)")
            }
            self.appointmentDateLbl.text = appInfo
            if patient?.initiatePayment == true {
                clearanceView.isUserInteractionEnabled = false
                cancelBtn.isHidden = true
                requestRecordBtn.isHidden = true
            }
            if (dateFormatter.date(from: appDate) ?? Date()).compare(Date().dateByIgnoringTime()) == .orderedAscending {
                if patient?.status != 0 {
                    clearanceView.isUserInteractionEnabled = false
                }
                cancelBtn.isHidden = true
                requestRecordBtn.isHidden = true
            }
        }
        let optionArray = patient?.anesthesiologistClinicASA?.map({ (asa: ASAModel) -> String in
            return ("\(asa.asa?.replacingOccurrences(of: "_", with: " ") ?? "") (\( units[Int(asa.asA_Value ?? "0") ?? 0].0))")
        }) ?? []
        if let data = patient?.asa, data != 0 {
            asaDD.selectedIndex = data - 1
            asaDD.text = optionArray[data - 1]
        }
        asaDD.optionArray = optionArray
        asaDD.didSelect { selectedText, index, id in
            self.asaDD.borderColor = UIColor(named: AssetColor.ViewBorder) ?? .black
            self.asaDD.text = ""
            self.viewModel.updateAsa(index: index, appId: self.appointmentId ?? 0) { _ in
                self.asaDD.text = selectedText
                self.viewModel.patientDetails?.asa = index + 1
                let storyboard = UIStoryboard(name: StoryBoard.main, bundle: nil)
                let vc = storyboard.instantiateViewController(withIdentifier: VCIdentifiers.AlertViewController) as! AlertViewController
                vc.alert = .single
                vc.image = self.successImage
                vc.message = "ASA updated successfully!!!"
                vc.modalPresentationStyle = .overFullScreen
                vc.modalTransitionStyle = .crossDissolve
                self.present(vc, animated: true)
            }
        }
        let clearedArray = ["Patient cleared", "Patient not cleared"]
        clearUpDD.optionArray = clearedArray
        if let data = patient?.isPatientCleared {
            clearUpDD.selectedIndex = data ? 0 : 1
            clearUpDD.text = data ? clearedArray[0] : clearedArray[1]
        }
        clearUpDD.didSelect { text, index, id in
            self.clearUpDD.borderColor = UIColor(named: AssetColor.ViewBorder) ?? .black
            self.clearUpDD.text = ""
            self.viewModel.updatepatientClearUp(appId: self.appointmentId ?? 0, status: index == 0) { _ in
                self.clearUpDD.text = text
                self.viewModel.patientDetails?.isPatientCleared = index == 0
                let storyboard = UIStoryboard(name: StoryBoard.main, bundle: nil)
                let vc = storyboard.instantiateViewController(withIdentifier: VCIdentifiers.AlertViewController) as! AlertViewController
                vc.alert = .single
                vc.image = self.successImage
                vc.message = "Patient clearup updated successfully!!!"
                vc.modalPresentationStyle = .overFullScreen
                vc.modalTransitionStyle = .crossDissolve
                self.present(vc, animated: true)
            }
        }
    }
    
    // MARK: - Actions
    @IBAction func callBtnClicked(_ sender: UIButton) {
        let phoneNo = Utility.getDecryptString(dataString: viewModel.patientDetails?.contactno ?? "")
        if let url = URL(string: "tel://\(phoneNo.replacingOccurrences(of: " ", with: ""))"), UIApplication.shared.canOpenURL(url) {
            UIApplication.shared.open(url)
        }
    }
    
    @IBAction func socialSecurityClicked(_ sender: UIButton) {
        if ssnBtnBool {
            let storyboard = UIStoryboard(name: StoryBoard.main, bundle: nil)
            let vc = storyboard.instantiateViewController(withIdentifier: VCIdentifiers.DaysPopUpViewController) as! DaysPopUpViewController
            vc.delegate = self
            vc.popUpScreen = .Password
            vc.modalTransitionStyle = .crossDissolve
            vc.modalPresentationStyle = .overFullScreen
            present(vc, animated: true)
        }
    }
    // Delegate Methods
    func reloadData() { /// Make Visible SSN
        socialSecNoLbl.text = Utility.getDecryptString(dataString: viewModel.patientDetails?.ssn ?? "")
        self.ssnBtnBool = false
    }
    
    func denyended() { /// Reload Patient Details
        viewModel.getPatientDetails(patientID: self.patientId ?? 0, appointmentId: self.appointmentId ?? 0)
    }
    
    @IBAction func requestMedicalRecordClicked(_ sender: RoundedButton) {
//   SelectTemplateViewController
        let storyBoard = UIStoryboard(name: StoryBoard.main, bundle: nil)
        let vc = storyBoard.instantiateViewController(withIdentifier: VCIdentifiers.RequestDocumentViewController) as! RequestDocumentViewController
        vc.appId = self.appointmentId
        vc.patientId = self.patientId
        vc.patientName = self.patientNameLbl.text
        vc.dob = self.dobLbl.text
        vc.surgeryDate = self.appointmentDate
        vc.surgeryName = self.viewModel.patientDetails?.surgeryName
        vc.clinicName = self.clinicName
        vc.delegate = self
        vc.modalTransitionStyle = .crossDissolve
        vc.modalPresentationStyle = .overFullScreen
        self.present(vc, animated: true, completion: nil)
    }
    
    @IBAction func addPrescriptionClicked(_ sender: RoundedButton) {
        let storyboard = UIStoryboard(name: StoryBoard.common, bundle: nil)
        let vc = storyboard.instantiateViewController(withIdentifier: VCIdentifiers.PrescriptionViewController) as! PrescriptionViewController
        vc.patientId = self.patientId
        vc.appointmentId = self.appointmentId
        vc.patientDetails = self.viewModel.patientDetails
        navigationController?.pushViewController(vc, animated: true)
    }
    
    @IBAction func backBtnClicked(_ sender: UIButton) {
        self.navigationController?.popViewController(animated: true)
    }
    
    @IBAction func hgBtnClicked(_ sender: RoundedButton) {
        if let id = viewModel.id {
            let storyboard = UIStoryboard(name: StoryBoard.common, bundle: nil)
            let vc = storyboard.instantiateViewController(withIdentifier: VCIdentifiers.HealthGorillaWebViewViewController) as! HealthGorillaWebViewViewController
            // uuid == "1234554321ABCDE" // iss == HGRequired.ssoIss
            let UUID = (getUesrInfo()?.hGSso == nil || getUesrInfo()?.hGSso == "") ? "1234554321ABCDE" : Utility.getDecryptString(dataString: getUesrInfo()?.hGSso ?? "").lowercased()
            vc.url = "\(Config.HG_BASE_URL)/prauth/login?assertion=\(BaseViewModel().HGJWT(secret: HGRequired.ssoSecret, UUID: UUID, iss: HGRequired.ssoIss, aud: HGRequired.ssoAud))&redirect_uri=\(Config.HG_BASE_URL)/clinicalnetwork#patient/chart&id=\(id)"
            self.navigationController?.pushViewController(vc, animated: true)
        }
    }
    
    @IBAction func hgToggleClicked(_ sender: UISwitch) {
        isPatient = sender.isOn
        medicalStackView.isHidden = !isPatient
        hgStackView.isHidden = isPatient
//            segmentControl.segment(at: 0)?.set(title: isPatient ? "Reported Conditions" : "Diagonses")
//            segmentControl.segment(at: 1)?.set(title: isPatient ? TitleConstant.medication.capitalized : "Vitals")
//            segmentControl.segment(at: 2)?.set(title: isPatient ? "Allergies" : "Labs")
//            segmentControl.segment(at: 3)?.set(title: isPatient ? "Surgical History" : TitleConstant.medication.capitalized)
//            segmentControl.segment(at: 4)?.set(title: isPatient ? "Anesthesia Hx" : "Allergies")
//        viewModel.redirectControllerClosure?()
//        NotificationCenter.default.post(name: NSNotification.Name(NotiCenterConstant.isPatient), object: isPatient)
//        self.activeLbl.isHidden = isPatient
//        self.activeSwitch.isHidden = isPatient
    }
    
    @IBAction func activeToggleClicked(_ sender: UISwitch) {
        NotificationCenter.default.post(name: NSNotification.Name(NotiCenterConstant.isActive), object: sender.isOn)
    }
    
    @IBAction func anesthesiaBtnClicked(_ sender: RoundedButton) {
        let storyboard = UIStoryboard(name: StoryBoard.anesthesiaRecord, bundle: nil)
        let vc = storyboard.instantiateViewController(withIdentifier: VCIdentifiers.AnesthesiaRecordMainViewController) as! AnesthesiaRecordMainViewController
        vc.appID = appointmentId
        vc.patientID = patientId
        navigationController?.pushViewController(vc, animated: true)
    }
    
    @IBAction func formsDidClicked(_ sender: UIButton) {
        let vc = storyBoard.instantiateViewController(withIdentifier: VCIdentifiers.PatientFormsViewController) as! PatientFormsViewController
        vc.patientData = self.viewModel.patientDetails
        vc.appID = self.appointmentId
        vc.delegate = self
        vc.isCancelled = self.viewModel.patientDetails?.status == 3
        vc.approvalClosure = {
            self.viewModel.patientDetails?.concent_Form?.forEach({
                $0.isApproved = true
            })
        }
        vc.modalTransitionStyle = .crossDissolve
        vc.modalPresentationStyle = .overFullScreen
        self.present(vc, animated: true)
    }
    
    @IBAction func emergencyContactDidClicked(_ sender: UIButton) {
        let vc = storyBoard.instantiateViewController(withIdentifier: VCIdentifiers.EmergencyContactViewController) as! EmergencyContactViewController
        vc.patientData = self.viewModel.patientDetails
        vc.modalTransitionStyle = .crossDissolve
        vc.modalPresentationStyle = .overFullScreen
        self.present(vc, animated: true)
    }
    
    @IBAction func treatingPhysicianDidClicked(_ sender: UIButton) {
        let vc = storyBoard.instantiateViewController(withIdentifier: VCIdentifiers.TreatingPhysicianViewController) as! TreatingPhysicianViewController
        vc.patientData = self.viewModel.patientDetails
        vc.modalTransitionStyle = .crossDissolve
        vc.modalPresentationStyle = .overFullScreen
        self.present(vc, animated: true)
    }
    
    @IBAction func caretakerDidClicked(_ sender: UIButton) {
        let vc = storyBoard.instantiateViewController(withIdentifier: VCIdentifiers.CaretakerViewController) as! CaretakerViewController
        vc.patientData = self.viewModel.patientDetails
        vc.modalTransitionStyle = .crossDissolve
        vc.modalPresentationStyle = .overFullScreen
        self.present(vc, animated: true)
    }
    
    @IBAction func requestedMrClicked(_ sender: UIButton) {
        let storyboard = UIStoryboard(name: StoryBoard.common, bundle: nil)
        let vc = storyboard.instantiateViewController(withIdentifier: VCIdentifiers.PendingDocumentDetailsViewController) as! PendingDocumentDetailsViewController
        vc.docType = .submitted
        vc.subDocuments = self.viewModel.submittedDocs
        navigationController?.pushViewController(vc, animated: true)
    }
    
    @IBAction func reportedConditionDidClicked(_ sender: UIButton) {
        let vc = storyBoard.instantiateViewController(withIdentifier: VCIdentifiers.SummaryViewController) as! SummaryViewController
        vc.patientId = self.patientId
        vc.appId = self.appointmentId
        vc.isPatient = self.isPatient
        vc.modalTransitionStyle = .crossDissolve
        vc.modalPresentationStyle = .overFullScreen
        self.present(vc, animated: true)
    }
    
    @IBAction func medPatientDidClicked(_ sender: UIButton) {
        let vc = storyBoard.instantiateViewController(withIdentifier: VCIdentifiers.MedicationViewController) as! MedicationViewController
        vc.patientId = self.patientId
        vc.appId = self.appointmentId
        vc.isPatient = self.isPatient
        vc.modalTransitionStyle = .crossDissolve
        vc.modalPresentationStyle = .overFullScreen
        self.present(vc, animated: true)
    }
    
    @IBAction func allergiesPatDidClicked(_ sender: UIButton) {
        let vc = storyBoard.instantiateViewController(withIdentifier: VCIdentifiers.AllergiesViewController) as! AllergiesViewController
        vc.patientId = self.patientId
        vc.appId = self.appointmentId
        vc.isPatient = self.isPatient
        vc.modalTransitionStyle = .crossDissolve
        vc.modalPresentationStyle = .overFullScreen
        self.present(vc, animated: true)
    }
    
    @IBAction func surgicalHistoryDidClicked(_ sender: UIButton) {
        let vc = storyBoard.instantiateViewController(withIdentifier: VCIdentifiers.SurgicalHistoryViewController) as! SurgicalHistoryViewController
        vc.patientId = self.patientId
        vc.appId = self.appointmentId
        vc.isPatient = self.isPatient
        vc.modalTransitionStyle = .crossDissolve
        vc.modalPresentationStyle = .overFullScreen
        self.present(vc, animated: true)
    }
    
    @IBAction func anesHxDidClicked(_ sender: UIButton) {
        let vc = storyBoard.instantiateViewController(withIdentifier: VCIdentifiers.LabsViewController) as! LabsViewController
        vc.patientId = self.patientId
        vc.appId = self.appointmentId
        vc.isPatient = self.isPatient
        vc.modalTransitionStyle = .crossDissolve
        vc.modalPresentationStyle = .overFullScreen
        self.present(vc, animated: true)
    }
    
    @IBAction func diagnosisDidClicked(_ sender: UIButton) {
        let vc = storyBoard.instantiateViewController(withIdentifier: VCIdentifiers.SummaryViewController) as! SummaryViewController
        vc.hgID = viewModel.id
        vc.isPatient = self.isPatient
        vc.modalTransitionStyle = .crossDissolve
        vc.modalPresentationStyle = .overFullScreen
        self.present(vc, animated: true)
    }
    
    @IBAction func vitalsDidClicked(_ sender: UIButton) {
        let vc = storyBoard.instantiateViewController(withIdentifier: VCIdentifiers.MedicationViewController) as! MedicationViewController
        vc.hgID = viewModel.id
        vc.isPatient = self.isPatient
        vc.modalTransitionStyle = .crossDissolve
        vc.modalPresentationStyle = .overFullScreen
        self.present(vc, animated: true)
    }
    
    @IBAction func labsDidClicked(_ sender: UIButton) {
        let vc = storyBoard.instantiateViewController(withIdentifier: VCIdentifiers.AllergiesViewController) as! AllergiesViewController
        vc.hgID = viewModel.id
        vc.isPatient = self.isPatient
        vc.modalTransitionStyle = .crossDissolve
        vc.modalPresentationStyle = .overFullScreen
        self.present(vc, animated: true)
    }
    
    @IBAction func medsHgDidClicked(_ sender: UIButton) {
        let vc = storyBoard.instantiateViewController(withIdentifier: VCIdentifiers.SurgicalHistoryViewController) as! SurgicalHistoryViewController
        vc.hgID = viewModel.id
        vc.isPatient = self.isPatient
        vc.modalTransitionStyle = .crossDissolve
        vc.modalPresentationStyle = .overFullScreen
        self.present(vc, animated: true)
    }
    
    @IBAction func AllerHgDidClicked(_ sender: UIButton) {
        let vc = storyBoard.instantiateViewController(withIdentifier: VCIdentifiers.LabsViewController) as! LabsViewController
        vc.hgID = viewModel.id
        vc.isPatient = self.isPatient
        vc.modalTransitionStyle = .crossDissolve
        vc.modalPresentationStyle = .overFullScreen
        self.present(vc, animated: true)
    }
    
    @IBAction func hpClicked(_ sender: UIButton) {
        let vc = storyBoard.instantiateViewController(withIdentifier: VCIdentifiers.HistoryAndPhysicalViewController) as! HistoryAndPhysicalViewController
        vc.hgID = viewModel.id
        vc.isHP = true
        vc.modalTransitionStyle = .crossDissolve
        vc.modalPresentationStyle = .overFullScreen
        self.present(vc, animated: true)
    }
    
    @IBAction func anesRecClicked(_ sender: UIButton) {
        let vc = storyBoard.instantiateViewController(withIdentifier: VCIdentifiers.HistoryAndPhysicalViewController) as! HistoryAndPhysicalViewController
        vc.hgID = viewModel.id
        vc.isHP = false
        vc.modalTransitionStyle = .crossDissolve
        vc.modalPresentationStyle = .overFullScreen
        self.present(vc, animated: true)
    }
}

// MARK: - Extension UIScrollViewDelegate
//extension PatientDetailsViewController : UIScrollViewDelegate {

//    func scrollViewDidEndScrollingAnimation(_ scrollView: UIScrollView) {
//        getScrollPosition(scrollView: scrollView)
//    }
    
//    func scrollViewDidScroll(_ scrollView: UIScrollView) {
//        getScrollPosition(scrollView: scrollView)
//    }
    
//    func getScrollPosition(scrollView: UIScrollView) {
//        if scrollView == segmantScrollView {
//            let position = CGFloat(scrollView.contentOffset.x / scrollView.frame.size.width)
//            segmentPos = Int(position)
//            switch position {
//            case 0: (isPatient) ? viewModel.getOtherPatient(patientId: patientId ?? 0, appId: appointmentId ?? 0) : viewModel.getSummaryHG(HGID: viewModel.id ?? "")
//            case 1: (isPatient) ? viewModel.getMedicationPatient(patientId: patientId ?? 0, appId: appointmentId ?? 0) : viewModel.getVitalSignsHG(HGID: viewModel.id ?? "")
//            case 2: (isPatient) ? viewModel.getAllergiesPatient(patientId: patientId ?? 0, appId: appointmentId ?? 0) : viewModel.getLabsHG(HGID: viewModel.id ?? "")
//            case 3: (isPatient) ? viewModel.getSurgicalPatient(patientId: patientId ?? 0, appId: appointmentId ?? 0) : viewModel.getMedicationHG(HGID: viewModel.id ?? "")
//            case 4: (isPatient) ? viewModel.getSummaryPatient(patientId: patientId ?? 0, appId: appointmentId ?? 0) : viewModel.getAllergyHG(HGID: viewModel.id ?? "")
//            default: break
//            }
//        }
//    }
//}
