//
//  LabsViewController.swift
//  MAPS
//
//  Created by shubhamfunde on 29/08/22.
//

import UIKit

class LabsViewController: BaseViewController {

    @IBOutlet weak var tableView: UITableView!
    @IBOutlet weak var noRecordLbl: UILabel!
    
    @IBOutlet weak var titleImageView: UIImageView!
    @IBOutlet weak var titleLbl: UILabel!
    @IBOutlet weak var activeLbl: UILabel!
    @IBOutlet weak var activeSwitch: UISwitch!
    
    lazy var viewModel: PatientDetailsPopUpViewModel = {
        let obj = PatientDetailsPopUpViewModel(service: UserService(), hgservice: HGService())
        self.baseVwModel = obj
        return obj
    }()
    
    var hgID: String?
    var patientId: Int?
    var appId: Int?
    
    var filterList: [AllergyEntry]?
    var allergiesList: [AllergyEntry]?
    var summaryPatient: [PatientSummaryModel]?
    var isActive = false
    var isPatient = true
    
    override func viewDidLoad() {
        super.viewDidLoad()
        let nib = UINib(nibName: CellIdentifiers.SummaryTableViewCell, bundle: nil)
        tableView.register(nib, forCellReuseIdentifier: CellIdentifiers.SummaryTableViewCell)
        if isPatient {
            viewModel.getSummaryPatient(patientId: self.patientId ?? 0, appId: self.appId ?? 0)
            activeSwitch.isHidden = true
            activeLbl.isHidden = true
        } else {
            viewModel.getAllergyHG(HGID: hgID ?? "")
            titleImageView.image = UIImage(named: AssetImages.Allergies_New)
            titleLbl.text = TitleConstant.Allergies
        }
//        NotificationCenter.default.addObserver(self, selector: #selector(updateData(_:)), name: NSNotification.Name(NotiCenterConstant.hgAllergies), object: nil)
//        NotificationCenter.default.addObserver(self, selector: #selector(updateData(_:)), name: NSNotification.Name(NotiCenterConstant.isActive), object: nil)
//        NotificationCenter.default.addObserver(self, selector: #selector(patientBoolData(_:)), name: NSNotification.Name(NotiCenterConstant.isPatient), object: nil)
//        NotificationCenter.default.addObserver(self, selector: #selector(updateData(_:)), name: NSNotification.Name(NotiCenterConstant.summary), object: nil)
        setUpClosure()
    }
    
    func setUpClosure() {
        viewModel.reloadListViewClosure = { [weak self]() in
            self?.summaryPatient = self?.viewModel.summaryData
            self?.tableView.reloadData()
        }
        
        viewModel.redirectControllerClosure = { [weak self]() in
            self?.allergiesList = self?.viewModel.allerData
            self?.filterData()
        }
    }
    
//    @objc func updateData(_ notification: Notification) {
//        if let noti = notification.object as? [AllergyEntry] {
//            allergiesList = noti
//            filterData()
//        } else if let noti = notification.object as? Bool {
//            self.isActive = noti
//            filterData()
//        } else if let noti = notification.object as? [PatientSummaryModel] {
//            self.summaryPatient = noti
//            tableView.reloadData()
//        }
//    }
//
//    @objc func patientBoolData(_ notification: Notification) {
//        if let noti = notification.object as? Bool {
//            self.isPatient = noti
//            tableView.reloadData()
//        }
//    }
    
    func filterData() {
        if isActive {
            filterList = allergiesList?.filter({
                $0.resource?.clinicalStatus?.text?.lowercased() == TitleConstant.active || $0.resource?.clinicalStatus?.coding?.first?.display?.lowercased() == TitleConstant.active
            })
        } else {
            filterList = allergiesList
        }
        tableView.reloadData()
    }
    @IBAction func valueDidChanged(_ sender: UISwitch) {
        self.isActive = sender.isOn
        self.filterData()
    }
    @IBAction func cancelDidClicked(_ sender: UIButton) {
        self.dismiss(animated: true)
    }
}

// MARK: - Extension UITableViewDelegate, UITableViewDataSource
extension LabsViewController: UITableViewDelegate, UITableViewDataSource {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        let count = isPatient ? summaryPatient?.count ?? 0 : filterList?.count ?? 0
        noRecordLbl.isHidden = count != 0
        return count
    }

    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: CellIdentifiers.SummaryTableViewCell, for: indexPath) as! SummaryTableViewCell
        cell.selectionStyle = .none
        if isPatient {
            let data = summaryPatient?[indexPath.row]
            cell.titleLbl.text = data?.questionName?.replacingOccurrences(of: "?", with: "")
            cell.subtitleLbl.text = ""
//            cell.rightLbl.text = data?.isYes == 1 ? TitleConstant.yes.capitalized : TitleConstant.no.capitalized
            cell.rightLbl.text = ""
            return cell
        }
        let data = filterList?[indexPath.row].resource
        var allergy = ""
        if let text = data?.code?.text?.capitalized {
            allergy = text
        } else {
            allergy = data?.code?.coding?.first?.display?.capitalized ?? TitleConstant.na
        }
        cell.titleLbl.text = allergy
        var statusText = ""
        if let status = data?.clinicalStatus {
            if let text = status.text?.capitalized {
                statusText = text
            } else if let display = status.coding?.first?.display?.capitalized {
                statusText = display
            } else {
                statusText = status.coding?.first?.code?.capitalized ?? TitleConstant.na
            }
        } else {
            statusText = TitleConstant.na
        }
        cell.rightLbl.text = statusText
        var reactionText = ""
        
        if let reaction = data?.reaction?.enumerated() {
            for (index, object) in reaction {
                reactionText.append(contentsOf: "\(object.manifestation?.first?.coding?.first?.display?.capitalized ?? "")\(object.severity != nil ? " (\(object.severity?.capitalized ?? ""))" : "" )\((data?.reaction?.count ?? 0) - 1 == index ? "" : "\n")")
            }
        } else {
            reactionText = TitleConstant.na
        }
        cell.subtitleLbl.text = "Reaction : \(reactionText)"
        return cell
    }
}
