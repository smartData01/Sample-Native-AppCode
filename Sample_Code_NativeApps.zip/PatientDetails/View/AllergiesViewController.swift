//
//  AllergiesViewController.swift
//  MAPS
//
//  Created by shubhamfunde on 20/07/22.
//

import UIKit

class AllergiesViewController: BaseViewController {

    @IBOutlet weak var tableView: UITableView!
    @IBOutlet weak var noRecordLbl: UILabel!
    
    @IBOutlet weak var titleImageView: UIImageView!
    @IBOutlet weak var titleLbl: UILabel!
    @IBOutlet weak var activeLbl: UILabel!
    @IBOutlet weak var activeSwitch: UISwitch!
    
    lazy var viewModel: PatientDetailsPopUpViewModel = {
        let obj = PatientDetailsPopUpViewModel(service: UserService(), hgservice: HGService())
        self.baseVwModel = obj
        return obj
    }()
    
    var hgID: String?
    var patientId: Int?
    var appId: Int?
    var labsList: [LabsEntry]?
    var allergiesList: [AllergiesPatientModel]?
    let dateFormatter = DateFormatter()
    let dateFormatterC = DateFormatter()
    var isPatient = true
    
    override func viewDidLoad() {
        super.viewDidLoad()
        dateFormatter.dateFormat = DatePickerFormat.yyyy_MM_dd_T_HH_mm_ss
        dateFormatterC.dateFormat = DatePickerFormat.MM_dd_yyyy
        
        activeSwitch.isHidden = true
        activeLbl.isHidden = true
        if isPatient {
            viewModel.getAllergiesPatient(patientId: self.patientId ?? 0, appId: self.appId ?? 0)
        } else {
            viewModel.getLabsHG(HGID: hgID ?? "")
            titleImageView.image = UIImage(named: AssetImages.Labs_New)
            titleLbl.text = TitleConstant.Labs
        }
        let nib = UINib(nibName: CellIdentifiers.SummaryTableViewCell, bundle: nil)
        tableView.register(nib, forCellReuseIdentifier: CellIdentifiers.SummaryTableViewCell)
        let allerNib = UINib(nibName: CellIdentifiers.TemplateTableViewCell, bundle: nil)
        tableView.register(allerNib, forCellReuseIdentifier: CellIdentifiers.TemplateTableViewCell)
//        NotificationCenter.default.addObserver(self, selector: #selector(updateData(_:)), name: NSNotification.Name(NotiCenterConstant.hgLabs), object: nil)
//        NotificationCenter.default.addObserver(self, selector: #selector(updateID(_:)), name: NSNotification.Name(NotiCenterConstant.hgID), object: nil)
//        NotificationCenter.default.addObserver(self, selector: #selector(patientBoolData(_:)), name: NSNotification.Name(NotiCenterConstant.isPatient), object: nil)
//        NotificationCenter.default.addObserver(self, selector: #selector(updateData(_:)), name: NSNotification.Name(NotiCenterConstant.allergies), object: nil)
        setUpClosure()
    }
    
    func setUpClosure() {
        viewModel.reloadListViewClosure = { [weak self]() in
            self?.allergiesList = self?.viewModel.allergiesData
            self?.tableView.reloadData()
        }
        viewModel.redirectControllerClosure = { [weak self]() in
            self?.labsList = self?.viewModel.labsData
            self?.tableView.reloadData()
        }
    }
    
//    @objc func updateData(_ notification: Notification) {
//        if let noti = notification.object as? [LabsEntry] {
//            labsList = noti
//            tableView.reloadData()
//        } else if let noti = notification.object as? [AllergiesPatientModel] {
////            allergiesList = noti.filter({
////                $0.isYes ?? false == true
////            })
//            allergiesList = noti
//            tableView.reloadData()
//        }
//    }
//
//    @objc func updateID(_ notification: Notification) {
//        if let noti = notification.object as? String {
//            hgId = noti
//        }
//    }
//
//    @objc func patientBoolData(_ notification: Notification) {
//        if let noti = notification.object as? Bool {
//            self.isPatient = noti
//            tableView.reloadData()
//        }
//    }
    
    @IBAction func cancelDidClicked(_ sender: UIButton) {
        self.dismiss(animated: true)
    }
    
    @IBAction func valueDidChanged(_ sender: UISwitch) {
        // No Need
    }
}

// MARK: - Extension UITableViewDelegate, UITableViewDataSource
extension AllergiesViewController: UITableViewDelegate, UITableViewDataSource {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        let count = isPatient ? allergiesList?.count ?? 0 : labsList?.count ?? 0
        noRecordLbl.isHidden = count != 0
        return count
    }

    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        if isPatient {
            let cell = tableView.dequeueReusableCell(withIdentifier: CellIdentifiers.TemplateTableViewCell, for: indexPath) as! TemplateTableViewCell
            let data = allergiesList?[indexPath.row]
            cell.arrowBtn.isHidden = true
            cell.arrowBtn.widthAnchor.constraint(equalToConstant: 0).isActive = true
            cell.templateNameLbl.text = data?.allergyName
            return cell
        }
        let cell = tableView.dequeueReusableCell(withIdentifier: CellIdentifiers.SummaryTableViewCell, for: indexPath) as! SummaryTableViewCell
        let data = labsList?[indexPath.row].resource
        cell.titleLbl.text = data?.performer?.first?.display ?? TitleConstant.na
        cell.subtitleLbl.text = data?.extension1?.first?.valueCodeableConcept?.text ?? data?.extension1?.first?.valueCodeableConcept?.coding?.first?.display ?? TitleConstant.na
        if data?.extension1?.first?.valueCodeableConcept?.text?.lowercased() == "abnormal" || data?.extension1?.first?.valueCodeableConcept?.coding?.first?.display?.lowercased() == "abnormal" {
            cell.subtitleLbl.textColor = .red
        } else {
            cell.subtitleLbl.textColor = UIColor(named: AssetColor.ThemeColorDark_75)
        }
        let date = dateFormatter.date(from: data?.issued ?? "")
        cell.rightLbl.text = dateFormatterC.string(from: date ?? Date())
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        tableView.deselectRow(at: indexPath, animated: true)
        if !isPatient {
            let storyBoard = UIStoryboard(name: StoryBoard.main, bundle: nil)
            let vc = storyBoard.instantiateViewController(withIdentifier: VCIdentifiers.DocumentPopUpViewController) as! DocumentPopUpViewController
            vc.data = labsList?[indexPath.row].resource?.result
            vc.hgId = hgID
            vc.modalTransitionStyle = .crossDissolve
            vc.modalPresentationStyle = .overFullScreen
            present(vc, animated: true, completion: nil)
        }
    }
}
