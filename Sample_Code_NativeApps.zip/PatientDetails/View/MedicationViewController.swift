//
//  MedicationViewController.swift
//  MAPS
//
//  Created by shubhamfunde on 20/07/22.
//

import UIKit

class MedicationViewController: BaseViewController {
    
    @IBOutlet weak var tableView: UITableView!
    @IBOutlet weak var noRecordLbl: UILabel!
    @IBOutlet weak var titleImageView: UIImageView!
    @IBOutlet weak var titleLbl: UILabel!
    @IBOutlet weak var activeSwitch: UISwitch!
    @IBOutlet weak var activeLbl: UILabel!
    
    lazy var viewModel: PatientDetailsPopUpViewModel = {
        let obj = PatientDetailsPopUpViewModel(service: UserService(), hgservice: HGService())
        self.baseVwModel = obj
        return obj
    }()
    
    var hgID: String?
    var patientId: Int?
    var appId: Int?
    var vitalList: [VitalEntry]?
    var medicationList: [MedicationPatientModel]?
    let dateFormatter = DateFormatter()
    let dateFormatterC = DateFormatter()
    var isPatient = true
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        dateFormatter.dateFormat = DatePickerFormat.yyyy_MM_dd
        dateFormatterC.dateFormat = DatePickerFormat.MM_dd_yyyy
        activeSwitch.isHidden = true
        activeLbl.isHidden = true
        if isPatient {
            viewModel.getMedicationPatient(patientId: self.patientId ?? 0, appId: self.appId ?? 0)
        } else {
            viewModel.getVitalSignsHG(HGID: hgID ?? "")
            titleImageView.image = UIImage(named: AssetImages.Vitals_New)
            titleLbl.text = TitleConstant.Vitals
        }
//        NotificationCenter.default.addObserver(self, selector: #selector(updateData(_:)), name: NSNotification.Name(NotiCenterConstant.hgVital), object: nil)
//        NotificationCenter.default.addObserver(self, selector: #selector(patientBoolData(_:)), name: NSNotification.Name(NotiCenterConstant.isPatient), object: nil)
//        NotificationCenter.default.addObserver(self, selector: #selector(updateData(_:)), name: NSNotification.Name(NotiCenterConstant.medication), object: nil)
        let nib = UINib(nibName: CellIdentifiers.SummaryTableViewCell, bundle: nil)
        let vitalNib = UINib(nibName: CellIdentifiers.VitalsTableViewCell, bundle: nil)
        tableView.register(nib, forCellReuseIdentifier: CellIdentifiers.SummaryTableViewCell)
        tableView.register(vitalNib, forCellReuseIdentifier: CellIdentifiers.VitalsTableViewCell)
        setUpClosure()
    }
    
    func setUpClosure() {
        viewModel.reloadListViewClosure = { [weak self]() in
            self?.medicationList = self?.viewModel.medicationsData
            self?.tableView.reloadData()
        }
        viewModel.redirectControllerClosure = { [weak self]() in
            self?.vitalList = self?.viewModel.vitalData
            self?.tableView.reloadData()
        }
    }
    
//    @objc func updateData(_ notification: Notification) {
//        if let noti = notification.object as? [VitalEntry] {
//            vitalList = noti
//            tableView.reloadData()
//        } else if let noti = notification.object as? [MedicationPatientModel] {
//            medicationList = noti
//            tableView.reloadData()
//        }
//    }
//
//    @objc func patientBoolData(_ notification: Notification) {
//        if let noti = notification.object as? Bool {
//            self.isPatient = noti
//            tableView.reloadData()
//        }
//    }
    
    @IBAction func cancelDidClicked(_ sender: UIButton) {
        self.dismiss(animated: true)
    }
    
    @IBAction func activeDidChanged(_ sender: UISwitch) {
        // No need for this
    }
}

// MARK: - Extension UITableViewDelegate, UITableViewDataSource
extension MedicationViewController : UITableViewDelegate, UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        let count = isPatient ? medicationList?.count ?? 0 : vitalList?.count ?? 0
        noRecordLbl.isHidden = count != 0
        return count
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {

        if isPatient {
            let cell = tableView.dequeueReusableCell(withIdentifier: CellIdentifiers.SummaryTableViewCell, for: indexPath) as! SummaryTableViewCell
            let data = medicationList?[indexPath.row]
            cell.selectionStyle = .none
            cell.titleLbl.text = data?.medicationName
            cell.subtitleLbl.text = data?.detail
            cell.rightLbl.isHidden = true
            return cell
        }
        let cell = tableView.dequeueReusableCell(withIdentifier: CellIdentifiers.VitalsTableViewCell, for: indexPath) as! VitalsTableViewCell
        let data = vitalList?[indexPath.row].resource
        var vitals = ""
        var practitioner = TitleConstant.na
        if let obj = data?.contained?.enumerated() {
            for (index, object) in obj {
                if object.resourceType == "Practitioner" {
                    practitioner = object.name?.first?.text ?? TitleConstant.na
                } else if object.resourceType == "Observation" {
                    vitals.append(contentsOf: "\( object.code?.first?.coding?.first?.display ?? "") : \(object.valueQuantity?.value ?? 0) \(object.valueQuantity?.unit ?? "")\((data?.contained?.count ?? 0) - 1 == index ? "" : "\n")")
                }
            }
        }
        
        cell.practitionerLbl.text = practitioner
        cell.vitalLbl.text = vitals
        var date = Date()
        if data?.effectiveDateTime?.contains("T") ?? false {
            if let index = data?.effectiveDateTime?.range(of: "T")?.lowerBound {
//                let substring = data?.effectiveDateTime?[..<index]
                let substring = data?.effectiveDateTime?.prefix(upTo: index)
                let string = String(substring ?? "")
                date = dateFormatter.date(from: string) ?? Date()
            }
        } else {
            date = dateFormatter.date(from: data?.effectiveDateTime ?? "") ?? Date()
        }
        cell.dateLbl.text = dateFormatterC.string(from: date)
        return cell
    }
}
