//
//  HistoryAndPhysicalViewController.swift
//  MAPS
//
//  Created by shubhamfunde on 06/02/23.
//

import UIKit

class HistoryAndPhysicalViewController: BaseViewController {

    @IBOutlet weak var titleImageView: UIImageView!
    @IBOutlet weak var titleLbl: UILabel!
    @IBOutlet weak var activeSwitch: UISwitch!
    @IBOutlet weak var activeLbl: UILabel!
    @IBOutlet weak var tableView: UITableView!
    @IBOutlet weak var noRecordLbl: UILabel!
    
    lazy var viewModel: PatientDetailsPopUpViewModel = {
        let obj = PatientDetailsPopUpViewModel(service: UserService(), hgservice: HGService())
        self.baseVwModel = obj
        return obj
    }()
    
    var hgID: String?
    var hPList: [HPEntry]?
    var anesList: [DocEntry]?
    var isHP: Bool?
    let dateFormatter = DateFormatter()
    let dateFormatterC = DateFormatter()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        dateFormatter.dateFormat = DatePickerFormat.yyyy_MM_dd
        dateFormatterC.dateFormat = DatePickerFormat.MM_dd_yyyy
        let nib = UINib(nibName: CellIdentifiers.SummaryTableViewCell, bundle: nil)
        tableView.register(nib, forCellReuseIdentifier: CellIdentifiers.SummaryTableViewCell)
        activeSwitch.isHidden = true
        activeLbl.isHidden = true
        if isHP ?? false {
            viewModel.getHPHG(HGID: hgID ?? "")
        } else {
            titleImageView.image = UIImage(named: AssetImages.AnesRec_New)
            titleLbl.text = TitleConstant.anesthesiaRecord
            viewModel.getAnesRec(HGID: hgID ?? "")
        }
        setUpClosure()
    }
    
    func setUpClosure() {
        viewModel.redirectControllerClosure = { [weak self]() in
            DispatchQueue.main.async {
                self?.hPList = self?.viewModel.hpData
                self?.anesList = self?.viewModel.anesRecData
                self?.tableView.reloadData()
            }
        }
    }
    
    @IBAction func cancelDidClicked(_ sender: UIButton) {
        self.dismiss(animated: true)
    }
}

// MARK: - Extension UITableViewDelegate, UITableViewDataSource
extension HistoryAndPhysicalViewController: UITableViewDelegate, UITableViewDataSource {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        let count = (isHP ?? false) ? (hPList?.count ?? 0) : (anesList?.count ?? 0)
        noRecordLbl.isHidden = count != 0
        return count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: CellIdentifiers.SummaryTableViewCell, for: indexPath) as! SummaryTableViewCell
        if isHP ?? false {
            let data = hPList?[indexPath.row].resource
            cell.titleLbl.text = data?.description ?? TitleConstant.na
            cell.subtitleLbl.text = data?.type?.text ?? TitleConstant.na
            let startDate = dateFormatter.date(from: data?.context?.period?.start ?? "")
            let endDate = dateFormatter.date(from: data?.context?.period?.end ?? "")
            cell.rightLbl.text = (startDate == nil ? TitleConstant.na : dateFormatterC.string(from: startDate ?? Date())) + (endDate == nil ? "" : " - \(dateFormatterC.string(from: endDate ?? Date()))")
            return cell
        } else {
            let data = anesList?[indexPath.row].resource
            cell.titleLbl.text = data?.description ?? TitleConstant.na
            cell.subtitleLbl.text = data?.type?.text ?? TitleConstant.na
            var date = Date()
            if data?.date?.contains("T") ?? false {
                if let index = data?.date?.range(of: "T")?.lowerBound {
    //                let substring = data?.effectiveDateTime?[..<index]
                    let substring = data?.date?.prefix(upTo: index)
                    let string = String(substring ?? "")
                    date = dateFormatter.date(from: string) ?? Date()
                }
            } else {
                date = dateFormatter.date(from: data?.date ?? "") ?? Date()
            }
            cell.rightLbl.text = dateFormatterC.string(from: date)
            return cell
        }
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        tableView.deselectRow(at: indexPath, animated: true)
        
        let storyBoard = UIStoryboard(name: StoryBoard.common, bundle: nil)
        let vc = storyBoard.instantiateViewController(withIdentifier: VCIdentifiers.HPPDFViewerViewController) as! HPPDFViewerViewController
        vc.hgDocID = (isHP ?? false) ? hPList?[indexPath.row].resource?.id : anesList?[indexPath.row].resource?.id
        vc.isHP = self.isHP
        vc.modalTransitionStyle = .crossDissolve
        vc.modalPresentationStyle = .overFullScreen
        self.present(vc, animated: true)
    }
}
