//
//  SummaryViewController.swift
//  MAPS
//
//  Created by shubhamfunde on 11/05/22.
//

import UIKit

class SummaryViewController: BaseViewController {

    @IBOutlet weak var tableView: UITableView!
    @IBOutlet weak var noRecordLbl: UILabel!
    @IBOutlet weak var titleImageView: UIImageView!
    @IBOutlet weak var titleLbl: UILabel!
    
    @IBOutlet weak var activeSwitch: UISwitch!
    @IBOutlet weak var activeLbl: UILabel!
    
    lazy var viewModel: PatientDetailsPopUpViewModel = {
        let obj = PatientDetailsPopUpViewModel(service: UserService(), hgservice: HGService())
        self.baseVwModel = obj
        return obj
    }()
    
    var hgID: String?
    var patientId: Int?
    var appId: Int?
    var isActive = false
    var isPatient = true
    var filterList: [Diagnoses]?
    var summaryList: [Diagnoses]?
    var otherList: [MedicalHistoryModel]?
    
    let dateformatter = DateFormatter()
    let dateformatter1 = DateFormatter()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        dateformatter.dateFormat = DatePickerFormat.yyyy_MM_dd_T_HH_mm_ss
        dateformatter1.dateFormat = DatePickerFormat.MM_dd_yyyy
        
        if isPatient {
            viewModel.getOtherPatient(patientId: self.patientId ?? 0, appId: self.appId ?? 0)
            activeSwitch.isHidden = true
            activeLbl.isHidden = true
        } else {
            viewModel.getSummaryHG(HGID: hgID ?? "")
            titleImageView.image = UIImage(named: AssetImages.Diagnosis_New)
            titleLbl.text = TitleConstant.Diagnoses
        }
//        NotificationCenter.default.addObserver(self, selector: #selector(updateData(_:)), name: NSNotification.Name(NotiCenterConstant.hgDiagnoses), object: nil)
//        NotificationCenter.default.addObserver(self, selector: #selector(updateData(_:)), name: NSNotification.Name(NotiCenterConstant.isActive), object: nil)
//        NotificationCenter.default.addObserver(self, selector: #selector(patientBoolData(_:)), name: NSNotification.Name(NotiCenterConstant.isPatient), object: nil)
//        NotificationCenter.default.addObserver(self, selector: #selector(updateData(_:)), name: NSNotification.Name(NotiCenterConstant.medicalHistory), object: nil)
        let nib = UINib(nibName: CellIdentifiers.SummaryTableViewCell, bundle: nil)
        tableView.register(nib, forCellReuseIdentifier: CellIdentifiers.SummaryTableViewCell)
        let nib1 = UINib(nibName: CellIdentifiers.SurgicalHistoryTableViewCell, bundle: nil)
        tableView.register(nib1, forCellReuseIdentifier: CellIdentifiers.SurgicalHistoryTableViewCell)
        setUpClosure()
    }
    
    func setUpClosure() {
        viewModel.reloadListViewClosure = { [weak self]() in
            self?.otherList = self?.viewModel.reportedConditionData
            self?.tableView.reloadData()
        }
        
        viewModel.redirectControllerClosure = { [weak self]() in
            self?.summaryList = self?.viewModel.diagnosesData
            self?.filterData()
        }
    }
    
//    @objc func updateData(_ notification: Notification) {
//        if let noti = notification.object as? [Diagnoses] {
//            summaryList = noti
//            filterData()
//        } else if let noti = notification.object as? Bool {
//            self.isActive = noti
//            filterData()
//        } else if let noti = notification.object as? [MedicalHistoryModel] {
//            otherList = noti
//            tableView.reloadData()
//        }
//    }
    
//    @objc func patientBoolData(_ notification: Notification) {
//        if let noti = notification.object as? Bool {
//            self.isPatient = noti
//            tableView.reloadData()
//        }
//    }
    
    func filterData() {
        if isActive {
            filterList = summaryList?.filter({
                $0.resource?.clinicalStatus?.coding?.first?.display?.lowercased() == TitleConstant.active
            })
        } else {
            filterList = summaryList
        }
        tableView.reloadData()
    }
    
    @IBAction func cancelDidClicked(_ sender: UIButton) {
        self.dismiss(animated: true)
    }
    
    @IBAction func activeDidChanged(_ sender: UISwitch) {
        self.isActive = sender.isOn
        filterData()
    }
}

// MARK: - Extension UITableViewDelegate, UITableViewDataSource
extension SummaryViewController : UITableViewDelegate, UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        let count = isPatient ? otherList?.count ?? 0 : filterList?.count ?? 0
        noRecordLbl.isHidden = count != 0
        return count
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: CellIdentifiers.SummaryTableViewCell, for: indexPath) as! SummaryTableViewCell
        cell.selectionStyle = .none
        if isPatient {
                let data = otherList?[indexPath.row]
                let cell = tableView.dequeueReusableCell(withIdentifier: CellIdentifiers.SurgicalHistoryTableViewCell, for: indexPath) as! SurgicalHistoryTableViewCell
                cell.selectionStyle = .none
                cell.leftTopLbl.text = "History"
                cell.leftTopDesLbl.text = data?.medicalName ?? ""
                if let date = dateformatter.date(from: data?.dateValue ?? "") {
                    cell.rightTopLbl.text = TitleConstant.date.capitalized
                    cell.rightTopDesLbl.text = dateformatter1.string(from: date)
                } else {
                    cell.rightTopLbl.text = ""
                    cell.rightTopDesLbl.text = ""
                }
                if let details = data?.detail, details != "" {
                    cell.leftBottomLbl.text = TitleConstant.details
                    cell.leftBottomDesLbl.text = details
                } else {
                    cell.leftBottomLbl.text = ""
                    cell.leftBottomDesLbl.text = ""
                }
                cell.RightBottomLbl.text = ""
                cell.rightBottomDesLbl.text = ""
                return cell
            
        }
        let data = filterList?[indexPath.row]
        cell.titleLbl.text = data?.resource?.code?.coding?.first?.display ?? TitleConstant.na
        let coding = data?.resource?.code?.coding?.first
        cell.subtitleLbl.text = ((coding?.system == "http://snomed.info/sct") ? "SNOMED CT®" : "ICD-10-CM") + " | " + (coding?.code ?? TitleConstant.na)
        cell.rightLbl.text = data?.resource?.clinicalStatus?.coding?.first?.display ?? TitleConstant.na
        return cell
    }
}
