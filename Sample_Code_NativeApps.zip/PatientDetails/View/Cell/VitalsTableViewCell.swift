//
//  VitalsTableViewCell.swift
//  MAPS
//
//  Created by shubhamfunde on 26/08/22.
//

import UIKit

class VitalsTableViewCell: UITableViewCell {

    @IBOutlet weak var dateLbl: UILabel!
    @IBOutlet weak var practitionerLbl: UILabel!
    @IBOutlet weak var vitalLbl: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
}
