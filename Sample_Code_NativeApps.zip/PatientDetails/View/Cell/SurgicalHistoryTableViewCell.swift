//
//  SurgicalHistoryTableViewCell.swift
//  MAPS
//
//  Created by shubhamfunde on 10/05/22.
//

import UIKit

class SurgicalHistoryTableViewCell: UITableViewCell {

    @IBOutlet weak var leftTopLbl: UILabel!
    @IBOutlet weak var rightTopLbl: UILabel!
    @IBOutlet weak var leftBottomLbl: UILabel!
    @IBOutlet weak var RightBottomLbl: UILabel!
    
    @IBOutlet weak var leftTopDesLbl: UILabel!
    @IBOutlet weak var rightTopDesLbl: UILabel!
    @IBOutlet weak var leftBottomDesLbl: UILabel!
    @IBOutlet weak var rightBottomDesLbl: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
}
