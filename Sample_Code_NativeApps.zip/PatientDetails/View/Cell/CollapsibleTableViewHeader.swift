//
//  CollapsibleTableViewHeader.swift
//  MAPS
//
//  Created by shubhamfunde on 10/05/22.
//

import UIKit

protocol CollapsibleTableViewHeaderDelegate {
    func toggleSection(_ header: UITableViewHeaderFooterView, section: Int)
}

class CollapsibleTableViewHeader: UITableViewHeaderFooterView {
    var delegate: CollapsibleTableViewHeaderDelegate?
    var section: Int = 0
    let titleLabel = UILabel()
    let arrowImage = UIImageView()
    let iPad = UIDevice.current.userInterfaceIdiom == .pad
    override init(reuseIdentifier: String?) {
        super.init(reuseIdentifier: reuseIdentifier)
        addGestureRecognizer(UITapGestureRecognizer(target: self, action: #selector(CollapsibleTableViewHeader.tapHeader(_:))))
        
        // Content View
        contentView.backgroundColor = UIColor.white
        contentView.layer.borderColor = UIColor(red: 0.24, green: 0.22, blue: 0.54, alpha: 0.10).cgColor
        contentView.layer.cornerRadius = 12
        contentView.layer.shadowColor = UIColor(red: 0.24, green: 0.22, blue: 0.54, alpha: 0.05).cgColor
        contentView.layer.shadowOffset = CGSize(width: 0.0, height: 2.0)
        contentView.layer.shadowOpacity = 1.0
        contentView.layer.shadowRadius = 4
        contentView.layer.masksToBounds = false
        
        let marginGuide = contentView.layoutMarginsGuide
        
        // Arrow Image
        
        let config = UIImage.SymbolConfiguration(weight: .bold)
        arrowImage.preferredSymbolConfiguration = config
       
        contentView.addSubview(arrowImage)
        arrowImage.image = UIImage.init(systemName: "chevron.down")?.withRenderingMode(.alwaysTemplate)
        arrowImage.tintColor = (UIColor(named: AssetColor.ThemeColorDark_75) ?? .gray)
        arrowImage.translatesAutoresizingMaskIntoConstraints = false
        arrowImage.widthAnchor.constraint(equalToConstant: iPad ? 23 : 13).isActive = true
//        arrowImage.heightAnchor.constraint(equalToConstant: iPad ? 17 : 7).isActive = true
        arrowImage.topAnchor.constraint(equalTo: marginGuide.topAnchor).isActive = true
        arrowImage.trailingAnchor.constraint(equalTo: marginGuide.trailingAnchor).isActive = true
        arrowImage.bottomAnchor.constraint(equalTo: marginGuide.bottomAnchor).isActive = true
        
        // Title label
        contentView.addSubview(titleLabel)
        titleLabel.textColor = UIColor(named: AssetColor.ThemeColorDark)
        titleLabel.font = UIFont(name: FontConstant.SFProDisplaySemiBold, size: iPad ? 18 : 14)
        titleLabel.translatesAutoresizingMaskIntoConstraints = false
        titleLabel.topAnchor.constraint(equalTo: marginGuide.topAnchor).isActive = true
        titleLabel.trailingAnchor.constraint(equalTo: marginGuide.trailingAnchor).isActive = true
        titleLabel.bottomAnchor.constraint(equalTo: marginGuide.bottomAnchor).isActive = true
        titleLabel.leadingAnchor.constraint(equalTo: marginGuide.leadingAnchor).isActive = true
    }
    
    @objc func tapHeader(_ gestureRecognizer: UITapGestureRecognizer) {
        guard let cell = gestureRecognizer.view as? CollapsibleTableViewHeader else {
            return
        }
        delegate?.toggleSection(self, section: cell.section)
    }
    
//    func setCollapsed(_ collapsed: Bool) {
//        // Animate the arrow rotation (see Extensions.swf)
////        arrowImage.rotate(collapsed ? 0.0 : .pi / 2)
//    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
}
