//
//  TreatingPhysicianTableViewCell.swift
//  MAPS
//
//  Created by shubhamfunde on 21/07/22.
//

import UIKit

class TreatingPhysicianTableViewCell: UITableViewCell {

    @IBOutlet weak var physicianNameLbl: UILabel!
    @IBOutlet weak var cityLbl: UILabel!
    @IBOutlet weak var stateLbl: UILabel!
    @IBOutlet weak var physicianContactLbl: UILabel!
    @IBOutlet weak var emailIdLbl: UILabel!
    @IBOutlet weak var specialityLbl: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
}
