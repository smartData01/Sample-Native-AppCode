//
//  EmergencyContactTableViewCell.swift
//  MAPS
//
//  Created by shubhamfunde on 20/07/22.
//

import UIKit

class EmergencyContactTableViewCell: UITableViewCell {

    @IBOutlet weak var contactNameLbl: UILabel!
    @IBOutlet weak var contactNoLbl: UILabel!
    @IBOutlet weak var contactRelationLbl: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
}
