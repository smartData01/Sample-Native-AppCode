//
//  ApproveDocumentTableViewCell.swift
//  MAPS
//
//  Created by shubhamfunde on 20/07/22.
//

import UIKit

class ApproveDocumentTableViewCell: UITableViewCell {

    @IBOutlet weak var approveDocumentBtn: RoundedButton!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
}
