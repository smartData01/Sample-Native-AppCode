//
//  TreatingPhysicianViewController.swift
//  MAPS
//
//  Created by shubhamfunde on 09/09/22.
//

import UIKit

class TreatingPhysicianViewController: BaseViewController {

    @IBOutlet weak var tableView: UITableView!
    @IBOutlet weak var noRecordLbl: UILabel!
    
    var patientData: PatientDetailsModel?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        NotificationCenter.default.addObserver(self, selector: #selector(updateData(_:)), name: NSNotification.Name(NotiCenterConstant.patientDetails), object: nil)
        let treatNib = UINib(nibName: CellIdentifiers.TreatingPhysicianTableViewCell, bundle: nil)
        tableView.register(treatNib, forCellReuseIdentifier: CellIdentifiers.TreatingPhysicianTableViewCell)
    }
    
    @objc func updateData(_ notification: Notification) {
        if let noti = notification.object as? PatientDetailsModel {
            patientData = noti
            tableView.reloadData()
        }
    }
    
    @IBAction func cancelDidClicked(_ sender: UIButton) {
        self.dismiss(animated: true)
    }
}

extension TreatingPhysicianViewController: UITableViewDelegate, UITableViewDataSource {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        let count = patientData?.treating_Physician?.count ?? 0
        noRecordLbl.isHidden = count != 0
        return count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: CellIdentifiers.TreatingPhysicianTableViewCell, for: indexPath) as! TreatingPhysicianTableViewCell
        let data = patientData?.treating_Physician?[indexPath.row]
        cell.physicianNameLbl.text = "Dr. \(data?.physicianName?.capitalized ?? "–")"
        cell.physicianContactLbl.text = data?.contactNo ?? "–"
        cell.emailIdLbl.text = (data?.email ?? "").trimmingCharacters(in: .whitespaces) == "" ? "–" : data?.email
        cell.cityLbl.text = data?.city?.capitalized ?? "–"
        cell.stateLbl.text = data?.state?.capitalized ?? "–"
        cell.specialityLbl.text = data?.speciality?.capitalized ?? "–"
        return cell
    }
}

