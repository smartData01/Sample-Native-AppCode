//
//  CaretakerViewController.swift
//  MAPS
//
//  Created by shubhamfunde on 09/09/22.
//

import UIKit

class CaretakerViewController: BaseViewController {

    @IBOutlet weak var nameLbl: UILabel!
    @IBOutlet weak var contactLbl: UILabel!
    @IBOutlet weak var relationLbl: UILabel!
    
    var patientData: PatientDetailsModel?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        if let patientData = patientData {
            nameLbl.text = patientData.caretakername ?? "" == "" ? "-" : Utility.getDecryptString(dataString: patientData.caretakername ?? "").capitalized
            contactLbl.text = patientData.caretakercontactno ?? "" == "" ? "-" : Utility.getDecryptString(dataString: patientData.caretakercontactno ?? "")
            relationLbl.text = patientData.caretakerrelationship ?? "" == "" ? "-" : Utility.getDecryptString(dataString: patientData.caretakerrelationship ?? "").capitalized
        }
    }
    
    @IBAction func cancelDidClicked(_ sender: UIButton) {
        self.dismiss(animated: true)
    }
}
