//
//  SurgicalHistoryViewController.swift
//  MAPS
//
//  Created by shubhamfunde on 20/07/22.
//

import UIKit

class SurgicalHistoryViewController: BaseViewController {

    @IBOutlet weak var tableView: UITableView!
    @IBOutlet weak var noRecordLbl: UILabel!
    
    @IBOutlet weak var titleImageView: UIImageView!
    @IBOutlet weak var titleLbl: UILabel!
    @IBOutlet weak var activeLbl: UILabel!
    @IBOutlet weak var activeSwitch: UISwitch!
    
    lazy var viewModel: PatientDetailsPopUpViewModel = {
        let obj = PatientDetailsPopUpViewModel(service: UserService(), hgservice: HGService())
        self.baseVwModel = obj
        return obj
    }()
    
    var hgID: String?
    var patientId: Int?
    var appId: Int?
    
    var filterList: [MedsEntry]?
    var medicationList: [MedsEntry]?
    var surgicalList: [SurgicalHistoryPatientModel]?
    var isActive = false
    var isPatient = true
    let dateformatter = DateFormatter()
    let dateformatter1 = DateFormatter()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        dateformatter.dateFormat = DatePickerFormat.yyyy_MM_dd_T_HH_mm_ss
        dateformatter1.dateFormat = DatePickerFormat.MM_dd_yyyy
        if isPatient {
            viewModel.getSurgicalPatient(patientId: self.patientId ?? 0, appId: self.appId ?? 0)
            activeSwitch.isHidden = true
            activeLbl.isHidden = true
        } else {
            viewModel.getMedicationHG(HGID: hgID ?? "")
            titleImageView.image = UIImage(named: AssetImages.Medication_New)
            titleLbl.text = TitleConstant.medication.capitalized
        }
        let nib = UINib(nibName: CellIdentifiers.SurgicalHistoryTableViewCell, bundle: nil)
        tableView.register(nib, forCellReuseIdentifier: CellIdentifiers.SurgicalHistoryTableViewCell)
//        NotificationCenter.default.addObserver(self, selector: #selector(updateData(_:)), name: NSNotification.Name(NotiCenterConstant.hgMeds), object: nil)
//        NotificationCenter.default.addObserver(self, selector: #selector(updateData(_:)), name: NSNotification.Name(NotiCenterConstant.isActive), object: nil)
//        NotificationCenter.default.addObserver(self, selector: #selector(updateData(_:)), name: NSNotification.Name(NotiCenterConstant.surgicalHistory), object: nil)
//        NotificationCenter.default.addObserver(self, selector: #selector(patientBoolData(_:)), name: NSNotification.Name(NotiCenterConstant.isPatient), object: nil)
        setUpClosure()
    }
    
    func setUpClosure() {
        viewModel.reloadListViewClosure = { [weak self]() in
            self?.surgicalList = self?.viewModel.surgicalData
            self?.tableView.reloadData()
        }
        
        viewModel.redirectControllerClosure = { [weak self]() in
            self?.medicationList = self?.viewModel.medsData
            self?.filterData()
        }
    }
    
//    @objc func updateData(_ notification: Notification) {
//        if let noti = notification.object as? [MedsEntry] {
//            medicationList = noti
//            filterData()
//        } else if let noti = notification.object as? Bool {
//            self.isActive = noti
//            filterData()
//        } else if let noti = notification.object as? [SurgicalHistoryPatientModel] {
//            self.surgicalList = noti
//            self.tableView.reloadData()
//        }
//    }
//
//    @objc func patientBoolData(_ notification: Notification) {
//        if let noti = notification.object as? Bool {
//            self.isPatient = noti
//            tableView.reloadData()
//        }
//    }
    
    func filterData() {
        if isActive {
            filterList = medicationList?.filter({
                $0.resource?.extension1?.first(where: {
                    $0.url == "http://hl7.org/fhir/3.0/StructureDefinition/extension-MedicationStatement.status"
                })?.valueString?.lowercased() == TitleConstant.active
            })
        } else {
            filterList = medicationList
        }
        tableView.reloadData()
    }
    
    @IBAction func cancelBtnClicked(_ sender: UIButton) {
        self.dismiss(animated: true)
    }
    
    @IBAction func valueDidChanged(_ sender: UISwitch) {
        self.isActive = sender.isOn
        filterData()
    }
}

// MARK: - Extension UITableViewDelegate, UITableViewDataSource
extension SurgicalHistoryViewController: UITableViewDelegate, UITableViewDataSource {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        let count = isPatient ? surgicalList?.count ?? 0 : filterList?.count ?? 0
        noRecordLbl.isHidden = count != 0
        return count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: CellIdentifiers.SurgicalHistoryTableViewCell, for: indexPath) as! SurgicalHistoryTableViewCell
        cell.selectionStyle = .none
        
        if isPatient {
            let data = surgicalList?[indexPath.row]
            cell.leftTopLbl.text = TitleConstant.surgery
            cell.leftTopDesLbl.text = data?.surgicalName ?? ""
//            if let date = dateformatter.date(from: data?.dateValue ?? "") {
//                cell.rightTopLbl.text = TitleConstant.date.capitalized
//                cell.rightTopDesLbl.text = dateformatter1.string(from: date)
//            } else {
                cell.rightTopLbl.text = ""
                cell.rightTopDesLbl.text = ""
//            }
            if let details = data?.detail, details != "" {
                cell.leftBottomLbl.text = TitleConstant.details
                cell.leftBottomDesLbl.text = details
            } else {
                cell.leftBottomLbl.text = ""
                cell.leftBottomDesLbl.text = ""
            }
            cell.RightBottomLbl.text = ""
            cell.rightBottomDesLbl.text = ""
            return cell
        }
        
        let data = filterList?[indexPath.row].resource
        cell.RightBottomLbl.text = ""
        cell.rightBottomDesLbl.text = ""
        cell.leftTopLbl.text = TitleConstant.medication.capitalized
        if let text = data?.medicationCodeableConcept?.text {
            cell.leftTopDesLbl.text = text
        } else if let text = data?.medicationCodeableConcept?.coding?.first?.display {
            cell.leftTopDesLbl.text = text
        } else {
            cell.leftTopDesLbl.text = data?.contained?.first(where: { $0.resourceType == TitleConstant.medication.capitalized
            })?.code?.first?.coding?.first?.display ?? "-"
        }
        cell.rightTopLbl.text = TitleConstant.status.capitalized
        cell.rightTopDesLbl.text = data?.extension1?.first(where: {
            $0.url == "http://hl7.org/fhir/3.0/StructureDefinition/extension-MedicationStatement.status"
        })?.valueString?.capitalized ?? TitleConstant.na
        cell.leftBottomLbl.text = "Instructions"
        var inst = TitleConstant.na
        if data?.dosage != nil {
            if let medsNote = data?.dosage?.first?.additionalInstruction {
                inst = medsNote.first?.text ?? TitleConstant.na
            }
        }
        cell.leftBottomDesLbl.text = inst
        return cell
    }
}
