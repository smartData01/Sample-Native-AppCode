//
//  EmergencyContactViewController.swift
//  MAPS
//
//  Created by shubhamfunde on 09/09/22.
//

import UIKit

class EmergencyContactViewController: BaseViewController {
    
    @IBOutlet weak var nameLbl: UILabel!
    @IBOutlet weak var contactLbl: UILabel!
    @IBOutlet weak var relationLbl: UILabel!
    
    var patientData: PatientDetailsModel?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        if let patientData = patientData {
            nameLbl.text = patientData.emergencycontactname ?? "" == "" ? "-" : Utility.getDecryptString(dataString: patientData.emergencycontactname ?? "").capitalized
            contactLbl.text = patientData.emergencycontactno ?? "" == "" ? "-" : Utility.getDecryptString(dataString: patientData.emergencycontactno ?? "")
            relationLbl.text = patientData.emergencycontactrelationship ?? "" == "" ? "-" : Utility.getDecryptString(dataString: patientData.emergencycontactrelationship ?? "").capitalized
        }
    }
    
    @IBAction func cancelDidClicked(_ sender: UIButton) {
        self.dismiss(animated: true)
    }
}
