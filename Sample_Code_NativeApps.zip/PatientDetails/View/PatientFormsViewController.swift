//
//  PatientFormsViewController.swift
//  MAPS
//
//  Created by shubhamfunde on 09/09/22.
//

import UIKit

class PatientFormsViewController: BaseViewController, DenyPopOverDelegate {

    @IBOutlet weak var tableView: UITableView!
    @IBOutlet weak var noRecordLbl: UILabel!
    
    var patientData: PatientDetailsModel?
    var appID: Int?
    var delegate: DenyPopOverDelegate?
    var isCancelled = false
    var approvalClosure: (()->())?
    
    lazy var viewModel: PatientDetailsPopUpViewModel = {
        let obj = PatientDetailsPopUpViewModel(service: UserService(), hgservice: HGService())
        self.baseVwModel = obj
        return obj
    }()
    
    override func viewDidLoad() {
        super.viewDidLoad()
//        NotificationCenter.default.addObserver(self, selector: #selector(updateData(_:)), name: NSNotification.Name(NotiCenterConstant.patientDetails), object: nil)
        NotificationCenter.default.addObserver(self, selector: #selector(updateData(_:)), name: NSNotification.Name(NotiCenterConstant.reloadPatientData), object: nil)
        let docNib = UINib(nibName: CellIdentifiers.DocumentTableViewCell, bundle: nil)
        tableView.register(docNib, forCellReuseIdentifier: CellIdentifiers.DocumentTableViewCell)
        let docBtnNib = UINib(nibName: CellIdentifiers.ApproveDocumentTableViewCell, bundle: nil)
        tableView.register(docBtnNib, forCellReuseIdentifier: CellIdentifiers.ApproveDocumentTableViewCell)
    }
    
    @objc func updateData(_ notification: Notification) {
        if let noti = notification.object as? PatientDetailsModel {
            patientData = noti
            tableView.reloadData()
        }
    }
    
    @IBAction func cancelDidClicked(_ sender: UIButton) {
        self.dismiss(animated: true)
    }
}

extension PatientFormsViewController: UITableViewDelegate, UITableViewDataSource {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        let count = (patientData?.concent_Form?.count ?? 0) + (patientData?.concent_Form?.first(where: {
            $0.isApproved ?? false == false
        }) == nil ? 0 : 1)
        noRecordLbl.isHidden = count != 0
        return count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let data = patientData?.concent_Form
        if data?.first(where: {
            $0.isApproved ?? false == false
        }) != nil {
            if indexPath.row == data?.count ?? 1 - 1 {
                let cell = tableView.dequeueReusableCell(withIdentifier: CellIdentifiers.ApproveDocumentTableViewCell, for: indexPath) as! ApproveDocumentTableViewCell
                cell.approveDocumentBtn.addTarget(self, action: #selector(approveClicked(_:)), for: .touchUpInside)
                return cell
            }
        }
        
        let cell = tableView.dequeueReusableCell(withIdentifier: CellIdentifiers.DocumentTableViewCell, for: indexPath) as! DocumentTableViewCell
        cell.leftView.backgroundColor = data?[indexPath.row].isSubmitted ?? false ? .green : .red
        cell.docNameLbl.text = data?[indexPath.row].formName
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        tableView.deselectRow(at: indexPath, animated: true)
        if patientData?.concent_Form?.first(where: {
            $0.isApproved ?? false == false
        }) != nil {
            if indexPath.row == patientData?.concent_Form?.count ?? 1 - 1 {
                return
            }
        }
        let data = patientData?.concent_Form?[indexPath.row]
        let storyboard = UIStoryboard(name: StoryBoard.common, bundle: nil)
        let vc = storyboard.instantiateViewController(withIdentifier: VCIdentifiers.ViewDocumentViewController) as! ViewDocumentViewController
        vc.docUrl = data?.formUrl
        if data?.formName?.lowercased() == "consent for anesthesia" && data?.isSubmitted == false {
            vc.delegate = self
        }
        vc.documentName = data?.formName
        vc.modalPresentationStyle = .overFullScreen
        vc.modalTransitionStyle = .crossDissolve
        self.present(vc, animated: true)
    }
    
    func denyended() {
        self.delegate?.denyended()
    }
    
    @objc func approveClicked(_ sender : UIButton) {
//        NotificationCenter.default.post(name: NSNotification.Name(NotiCenterConstant.approveBtn), object: nil)
        let submission = patientData?.concent_Form?.contains(where: {
            $0.isSubmitted == false
        }) ?? false
        if !submission && !isCancelled {
            self.viewModel.approveDocuments(appointmentId: self.appID ?? 0, anesthesiologistId: getUesrInfo()?.id ?? 0) { _ in
                let storyboard = UIStoryboard(name: StoryBoard.main, bundle: nil)
                let vc = storyboard.instantiateViewController(withIdentifier: VCIdentifiers.AlertViewController) as? AlertViewController
                vc?.image = self.successImage
                vc?.alert = .single
                vc?.message = MessagesConstant.documentApproved
                vc?.didClicked = {
                    self.patientData?.concent_Form?.forEach({
                        $0.isApproved = true
                    })
                    self.tableView.reloadData()
    //                self.delegate?.denyended()
                    self.approvalClosure?()
                }
                vc?.modalPresentationStyle = .overFullScreen
                vc?.modalTransitionStyle = .crossDissolve
                self.present(vc!, animated: true, completion: nil)
            }
        } else {
            let storyboard = UIStoryboard(name: StoryBoard.main, bundle: nil)
            let vc = storyboard.instantiateViewController(withIdentifier: VCIdentifiers.AlertViewController) as? AlertViewController
            vc?.image = self.errorImage
            vc?.alert = .single
            vc?.message = isCancelled ? MessagesConstant.cancelledAppointmentForms : MessagesConstant.approvalValidation
            vc?.modalPresentationStyle = .overFullScreen
            vc?.modalTransitionStyle = .crossDissolve
            self.present(vc!, animated: true, completion: nil)
        }
    }
}
