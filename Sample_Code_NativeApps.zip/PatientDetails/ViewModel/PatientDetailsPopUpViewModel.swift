//
//  PatientDetailsPopUpViewModel.swift
//  MAPS
//
//  Created by shubhamfunde on 25/01/23.
//

import UIKit

class PatientDetailsPopUpViewModel: BaseViewModel {
    private(set) var service:UserService
    private(set) var hgService:HGService
    
    init(service:UserService,hgservice: HGService ) {
        self.service = service
        self.hgService = hgservice
    }
    
    var reportedConditionData : [MedicalHistoryModel]? {
        didSet {
            self.reloadListViewClosure?()
        }
    }
    
    var diagnosesData : [Diagnoses]? {
        didSet {
            self.redirectControllerClosure?()
        }
    }
    
    var medicationsData : [MedicationPatientModel]? {
        didSet {
            self.reloadListViewClosure?()
        }
    }
    
    var vitalData : [VitalEntry]? {
        didSet {
            self.redirectControllerClosure?()
        }
    }
    
    var allergiesData : [AllergiesPatientModel]? {
        didSet {
            self.reloadListViewClosure?()
        }
    }
    
    var labsData : [LabsEntry]? {
        didSet {
            self.redirectControllerClosure?()
        }
    }
    
    var surgicalData: [SurgicalHistoryPatientModel]? {
        didSet {
            self.reloadListViewClosure?()
        }
    }
    
    var medsData : [MedsEntry]? {
        didSet {
            self.redirectControllerClosure?()
        }
    }
    
    var summaryData : [PatientSummaryModel]? {
        didSet {
            self.reloadListViewClosure?()
        }
    }
    
    var allerData : [AllergyEntry]? {
        didSet {
            self.redirectControllerClosure?()
        }
    }
    
    var hpData : [HPEntry]? {
        didSet {
            self.redirectControllerClosure?()
        }
    }
    
    var anesRecData: [DocEntry]? {
        didSet {
            self.redirectControllerClosure?()
        }
    }
    
    var dataPDF: Data? {
        didSet {
            self.reloadListViewClosure?()
        }
    }
    
    func getOtherPatient(patientId: Int, appId: Int) {
        self.isLoading = true
        let param = [Keys.patientId : "\(patientId)", Keys.appointmentId : "\(appId)"]
        service.getMedicalHistory(params: param) { data in
            DispatchQueue.main.async {
                self.isLoading = false
                if let data = data as? [MedicalHistoryModel] {
                    self.reportedConditionData = data
                } else {
                    if data as? String != MessagesConstant.dataNotFound {
                        self.errorMessage = (data as? String) ?? ErrorMessage.error
                    }
                }
            }
        }
    }
    
    func getSummaryHG(HGID: String) {
        self.isLoading = true
        hgService.getDiagnoses(HGID: HGID) { data in
            DispatchQueue.main.async {
                self.isLoading = false
                if let data = data as? [Diagnoses] {
                    
                    self.diagnosesData = data.filter({
                        $0.resource?.code?.coding?.first?.system != "http://hl7.org/fhir/sid/icd-9"
                    })
                } else {
                    self.errorMessage = (data as? String) ?? ErrorMessage.error
                }
            }
        }
    }
    
    func getMedicationPatient(patientId: Int, appId: Int) {
        self.isLoading = true
        let param = [Keys.patientId : "\(patientId)", Keys.appointmentId : "\(appId)"]
        service.getMedication(params: param) { data in
            DispatchQueue.main.async {
                self.isLoading = false
                if let data = data as? [MedicationPatientModel] {
                    self.medicationsData = data
                } else {
                    if data as? String != MessagesConstant.dataNotFound {
                        self.errorMessage = (data as? String) ?? ErrorMessage.error
                    }
                }
            }
        }
    }
    
    func getVitalSignsHG(HGID: String) {
        self.isLoading = true
        hgService.getVitalHG(HGID: HGID) { data in
            DispatchQueue.main.async {
                self.isLoading = false
                if let data = data as? [VitalEntry] {
                    self.vitalData = data
                } else {
                    self.errorMessage = (data as? String) ?? ErrorMessage.error
                }
            }
        }
    }
    
    func getAllergiesPatient(patientId: Int, appId: Int) {
        self.isLoading = true
        let param = [Keys.patientId : "\(patientId)", Keys.appointmentId : "\(appId)"]
        service.getAllergies(params: param) { data in
            DispatchQueue.main.async {
                self.isLoading = false
                if let data = data as? [AllergiesPatientModel] {
                    self.allergiesData = data
                } else {
                    if data as? String != MessagesConstant.dataNotFound {
                        self.errorMessage = (data as? String) ?? ErrorMessage.error
                    }
                }
            }
        }
    }
    
    func getLabsHG(HGID: String) {
        self.isLoading = true
        hgService.getLabsHG(HGID: HGID) { data in
            DispatchQueue.main.async {
                self.isLoading = false
                if let data = data as? [LabsEntry] {
                    self.labsData = data
                } else {
                    self.errorMessage = (data as? String) ?? ErrorMessage.error
                }
            }
        }
    }
    
    func getSurgicalPatient(patientId: Int, appId: Int) {
        self.isLoading = true
        let param = [Keys.patientId : "\(patientId)", Keys.appointmentId : "\(appId)"]
        service.getSurgicalHistory(params: param) { data in
            DispatchQueue.main.async {
                self.isLoading = false
                if let data = data as? [SurgicalHistoryPatientModel] {
                    self.surgicalData = data
                } else {
                    if data as? String != MessagesConstant.dataNotFound {
                        self.errorMessage = (data as? String) ?? ErrorMessage.error
                    }
                }
            }
        }
    }
    
    func getMedicationHG(HGID: String) {
        self.isLoading = true
        hgService.getMedsHG(HGID: HGID) { data in
            DispatchQueue.main.async {
                self.isLoading = false
                if let data = data as? [MedsEntry] {
                    self.medsData = data
                } else {
                    self.errorMessage = (data as? String) ?? ErrorMessage.error
                }
            }
        }
    }
    
    func getSummaryPatient(patientId: Int, appId: Int) {
        self.isLoading = true
        let param = [Keys.patientId : "\(patientId)", Keys.appointmentId : "\(appId)"]
        service.getPatientSummary(params: param) { data in
            DispatchQueue.main.async {
                self.isLoading = false
                if let data = data as? [PatientSummaryModel] {
                    self.summaryData = data
                } else {
                    if data as? String != MessagesConstant.dataNotFound {
                        self.errorMessage = (data as? String) ?? ErrorMessage.error
                    }
                }
            }
        }
    }
    
    func getAllergyHG(HGID: String) {
        self.isLoading = true
        hgService.getAllergiesHG(HGID: HGID) { data in
            DispatchQueue.main.async {
                self.isLoading = false
                if let data = data as? [AllergyEntry] {
                    self.allerData = data
                } else {
                    self.errorMessage = (data as? String) ?? ErrorMessage.error
                }
            }
        }
    }
    
    func approveDocuments(appointmentId: Int, anesthesiologistId: Int, completion: @escaping(Any?) -> Void) {
        self.isLoading = true
        service.approveDocument(appId: appointmentId, anesID: anesthesiologistId) { data in
            DispatchQueue.main.async {
                if let data = data as? String {
                    self.errorMessage = data
                } else {
                    completion(data)
                }
                self.isLoading = false
            }
        }
    }
    
    func getHPHG(HGID: String) {
        self.isLoading = true
        hgService.getHPHG(HGID: HGID) { data in
            DispatchQueue.main.async {
                self.isLoading = false
                if let data = data as? [HPEntry] {
                    self.hpData = data
                } else {
                    self.errorMessage = (data as? String) ?? ErrorMessage.error
                }
            }
        }
    }
    
    func getAnesRec(HGID: String) {
        self.isLoading = true
        hgService.getDocs(HGID: HGID) { data in
            DispatchQueue.main.async {
                self.isLoading = false
                if let data = data as? [DocEntry] {
                    
                    self.anesRecData = data.filter({
                        return ($0.resource?.text?.div?.range(of: "anesthesia record", options: .caseInsensitive) != nil) || ($0.resource?.text?.div?.range(of: "anesthesiology record", options: .caseInsensitive) != nil) || ($0.resource?.text?.div?.range(of: "anesthesia report", options: .caseInsensitive) != nil) || ($0.resource?.text?.div?.range(of: "anesthesiology report", options: .caseInsensitive) != nil) || ($0.resource?.description?.range(of: "anesthesia record", options: .caseInsensitive) != nil) || ($0.resource?.description?.range(of: "anesthesiology record", options: .caseInsensitive) != nil) || ($0.resource?.description?.range(of: "anesthesia report", options: .caseInsensitive) != nil) || ($0.resource?.description?.range(of: "anesthesiology report", options: .caseInsensitive) != nil) || ($0.resource?.author?.first?.display?.range(of: "anesthesia record", options: .caseInsensitive) != nil) || ($0.resource?.author?.first?.display?.range(of: "anesthesiology record", options: .caseInsensitive) != nil) || ($0.resource?.author?.first?.display?.range(of: "anesthesia report", options: .caseInsensitive) != nil) || ($0.resource?.author?.first?.display?.range(of: "anesthesiology report", options: .caseInsensitive) != nil)
                    })
                } else {
                    self.errorMessage = (data as? String) ?? ErrorMessage.error
                }
            }
        }
    }
    
    func getPDFUrl(docId: String) {
        self.isLoading = true
        hgService.getPDF(id: docId) { data in
            DispatchQueue.main.async {
                self.isLoading = true
                if let data = data as? [HGPDFModel] {
                    self.getPDF(url: data.first(where: {
                        $0.name == "url"
                    })?.valueString ?? "")
                } else {
                    self.isLoading = false
                    self.errorMessage = (data as? String) ?? ErrorMessage.error
                }
            }
        }
    }
    
    func getPDF(url: String) {
        self.isLoading = true
        let url = url.replacingOccurrences(of: Config.HG_BASE_URL, with: "").replacingOccurrences(of: Config.HG_BASE_API_URL, with: "")
        hgService.loadPDFHG(url: url) { data in
            DispatchQueue.main.async {
                self.isLoading = false
                if let data = data as? Data {
                    self.dataPDF = data
                } else {
                    self.errorMessage = (data as? String) ?? ErrorMessage.error
                }
            }
        }
    }
}
