//
//  PatientDetailsViewModel.swift
//  MAPS
//
//  Created by shubhamfunde on 11/05/22.
//

import UIKit

class PatientDetailsViewModel: BaseViewModel {
    
    private(set) var service:UserService
    private(set) var hgService:HGService
    
    init(service:UserService,hgservice: HGService ) {
        self.service = service
        self.hgService = hgservice
    }
    
    var dataPDF: Data? {
        didSet {
            self.reloadListViewClosure?()
        }
    }
    
    var patientDetails : PatientDetailsModel? {
        didSet {
            self.reloadListViewClosure?()
            NotificationCenter.default.post(name: NSNotification.Name(NotiCenterConstant.patientDetails), object: patientDetails)
        }
    }
    
    var reportData : [ReportEntry]? {
        didSet {
            NotificationCenter.default.post(name: NSNotification.Name(NotiCenterConstant.hgReport), object: reportData)
        }
    }
    
    var emailList = [TemplateModel]() {
        didSet {
            self.reloadListViewClosure?()
        }
    }
    
    var physicianList: [TreatingPhysicianModel]? {
        didSet {
            self.reloadListViewClosure?()
        }
    }
    
    var draftDocs: String? {
        didSet {
            self.redirectControllerClosure?()
        }
    }
    
    var id: String? {
        didSet {
            self.redirectControllerClosure?()
            if patientDetails?.hgId == nil || patientDetails?.hgId == "" {
                updateHGID()
            }
        }
    }
    
    var submittedDocs: [SubmittedDocumentsModel]?
    
    var HGId: String?
    var CWId: String?
    
    var firstName: String?
    var lastName: String?
    var address: String?
    var dob: String?
    var gender: String?
    var city: String?
    var state: String?
    var zipCode: String?
    
    var patientId: Int?
    
    func getPatientDetails(patientID: Int, appointmentId: Int) {
        self.isLoading = true
        self.patientId = patientID
        var param = [String:Any]()
        param[Keys.Patient_id] = String(patientID)
        param[Keys.appointment_Id] = String(appointmentId)
        service.getPatientDetails(params: param) { data in
            DispatchQueue.main.async {
                self.isLoading = false
                if let data = data as? PatientDetailsModel {
                    self.patientDetails = data
                } else {
                    self.errorMessage = (data as? String) ?? ErrorMessage.error
                }
                NotificationCenter.default.post(name: NSNotification.Name(NotiCenterConstant.reloadPatientData), object: self.patientDetails)
            }
        }
    }
    
    func updateAsa(index: Int, appId: Int, completion: @escaping(Any?) -> Void) {
        let param = [Keys.appointmentId: appId, Keys.asa: index + 1, Keys.asA_Value : Int(patientDetails?.anesthesiologistClinicASA?[index].asA_Value ?? "0") ?? 0] as [String:Any]
        self.isLoading = true
        service.updateAsa(params: param) { (data) in
            DispatchQueue.main.async {
                self.isLoading = false
                if let data = data as? String {
                    self.errorMessage = data
                } else {
                    completion(data)
                }
            }
        }
    }
    
    func updatepatientClearUp(appId: Int, status: Bool, completion: @escaping(Any?) -> Void) {
        let param = [Keys.appointment_Id: "\(appId)", Keys.isPatientCleared: "\(status)"]
        self.isLoading = true
        service.updateClearUp(params: param) { data in
            DispatchQueue.main.async {
                self.isLoading = false
                if let data = data as? String {
                    self.errorMessage = data
                } else {
                    completion(data)
                }
            }
        }
    }
    
    func updateHGID() {
        let param = [Keys.patient_Id : patientId ?? 0, Keys.hgId : self.id ?? ""] as [String : Any]
        service.updatePatientHGID(params: param) { data in
            DispatchQueue.main.async {
                if let data = data as? String, data != "Data Saved Successfully" {
                    self.errorMessage = data
                }
            }
        }
    }
    
    func callOAuth(HGID: String) {
        self.isLoading = true
        getOAuthToken { data, status in
            DispatchQueue.main.async {
                self.isLoading = false
                if status ?? false {
                    self.id = HGID
                } else {
                    self.isLoading = false
                    self.errorMessage = data ?? ErrorMessage.error
                }
            }
        }
    }
    
    func getEmailTemplateAPI() {
        let param = [Keys.anesthesiologist_id: "\(getUesrInfo()?.id ?? 0)"] as [String:Any]
        self.isLoading = true
        service.getEmailTemplate(params: param) { (data) in
            DispatchQueue.main.async {
                self.emailList.removeAll()
                self.isLoading = false
                if let data = data as? [TemplateModel] {
                    self.emailList = data
                } else {
                    if data as! String != MessagesConstant.dataNotFound {
                        self.errorMessage = (data as? String) ?? ErrorMessage.error
                    }
                }
            }
        }
    }
    
    func getLabsReportHG(HGID: String) {
        self.isLoading = true
        hgService.getAllLabsResultHG(HGID: HGID) { data in
            DispatchQueue.main.async {
                self.isLoading = false
                if let data = data as? [ReportEntry] {
                    self.reportData = data
                } else {
                    self.errorMessage = (data as? String) ?? ErrorMessage.error
                }
            }
        }
    }
    
    func getOAuthToken(completion: @escaping (String?,Bool?) -> Void) {
        let postData = NSMutableData(data: "grant_type=urn:ietf:params:oauth:grant-type:jwt-bearer".data(using: String.Encoding.utf8)!)
        postData.append("&scope=export_ccd create_users import_ccd patient360 user/*.*".data(using: String.Encoding.utf8)!)
        postData.append("&client_id=\(HGRequired.clientID)".data(using: String.Encoding.utf8)!)
        //        uuid : shubham.funde // test.maps.staff
        let UUID = (getUesrInfo()?.hGUserId == nil || getUesrInfo()?.hGUserId == "") ? "salman.hussain" : Utility.getDecryptString(dataString: getUesrInfo()?.hGUserId ?? "").lowercased()
        postData.append("&assertion=\(self.HGJWT(secret: HGRequired.secretToken, UUID: UUID, iss: HGRequired.tokenIss, aud: HGRequired.tokenAud))".data(using: String.Encoding.utf8)!)
        hgService.oauthToken(body: postData as Data) { data, status in
            completion(data, status)
        }
    }
    
    func searchPatient(firstName: String, lastName: String, address: String, dob: String, gender: String, city: String, state: String, zipCode: String) {
        /// Search patient in Patient 360
        self.isLoading = true
        self.firstName = firstName
        self.lastName = lastName
        self.address = address
        self.dob = dob
        self.city = city
        self.state = state
        self.zipCode = zipCode
        self.gender = gender
        
        getOAuthToken() { data, status in
            DispatchQueue.main.async {
                if status ?? false {
                    let dict = ["gender":gender,"given":firstName,"family":lastName,"birthdate":dob,"address-postalcode":zipCode]
                    self.hgService.searchPatient(body: dict) { data, status in
                        if status ?? false {
                            if let _ = data as? Bool {
                                self.createPatient()
                            } else {
                                self.isLoading = false
                                if let data = data as? HGPatientModel {
                                    if data.entry?.count ?? 0 > 0 {
                                        if data.entry?[0].resource?.extension1?.count ?? 0 > 0 {
                                            if data.entry?[0].resource?.extension1?[0].extension1?.count ?? 0 > 0 {
                                                if data.entry?[0].resource?.extension1?[0].extension1?[0].valueBoolean != nil {
                                                    if data.entry?[0].resource?.extension1?[0].extension1?[0].valueBoolean ?? false {
                                                        self.id = data.entry?[0].resource?.id
                                                    } else {
                                                        self.HGId = data.entry?[0].resource?.id
                                                        self.cwSearch()
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        } else {
                            self.isLoading = false
                            self.errorMessage = (data as? String) ?? ErrorMessage.error
                        }
                    }
                } else {
                    self.isLoading = false
                    self.errorMessage = data ?? ErrorMessage.error
                }
            }
        }
    }
    
    func createPatient() {
        /// Create Patient
        var params = [String:Any]()
        params["gender"] = self.gender ?? ""
        params["birthDate"] = self.dob ?? ""
        params["resourceType"] = "Patient"
        let name = ["use":"usual","family":self.lastName ?? "","given":[self.firstName ?? ""]] as [String : Any]
        let address = ["use":"home","type":"both","line":[self.address ?? ""],"city":self.city ?? "","state":self.state ?? "","postalCode": self.zipCode ?? ""] as [String : Any]
        params["name"] = [name]
        params["address"] = [address]
        hgService.createPatient(body: params) { data, status in
            DispatchQueue.main.async {
                if status ?? false {
                    self.HGId = data as? String
                    self.cwSearch()
                } else {
                    self.isLoading = false
                    self.errorMessage = (data as? String) ?? ErrorMessage.error
                }
            }
        }
    }
    
    func cwSearch() {
        /// Search Patient in CW
        hgService.cwSearch(HGId: self.HGId ?? "") { data, status in
            DispatchQueue.main.async {
                if status ?? false {
                    if let _ = data as? Bool {
                        self.cwLookUP()
                    } else {
                        self.CWId = data as? String ?? ""
                        self.enrollPatient()
                    }
                } else {
                    self.isLoading = false
                    self.errorMessage = (data as? String) ?? ErrorMessage.error
                }
            }
        }
    }
    
    func cwLookUP() {
        /// Lookup Patient in CW
        hgService.cwLookup(HGId: self.HGId ?? "") { data, status in
            DispatchQueue.main.async {
                if status ?? false {
                    if let _ = data as? Bool {
                        self.isLoading = false
                        self.errorMessage = ErrorMessage.error
                    } else {
                        self.CWId = data as? String ?? ""
                        self.enrollPatient()
                    }
                } else {
                    self.isLoading = false
                    self.errorMessage = (data as? String) ?? ErrorMessage.error
                }
            }
        }
    }
    
    func enrollPatient() {
        /// Enroll Patient
        hgService.enroll(HGId: self.HGId ?? "", CWId: self.CWId ?? "") { data, status in
            DispatchQueue.main.async {
                if status ?? false {
                    if let _ = data as? Bool {
                        self.searchPatientInCQCW()
                    } else {
                        self.isLoading = false
                        self.errorMessage = (data as? String) ?? ErrorMessage.error
                    }
                } else {
                    self.isLoading = false
                    self.errorMessage = (data as? String) ?? ErrorMessage.error
                }
            }
        }
    }
    
    func searchPatientInCQCW() {
        /// Search Patient in CQ & CW
        hgService.searchpatientCQCW(HGId: self.HGId ?? "") { data, status in
            DispatchQueue.main.async {
                if status ?? false {
                    self.asyncPatient(url: data ?? "")
                } else {
                    self.isLoading = false
                    self.errorMessage = (data) ?? ErrorMessage.error
                }
            }
        }
    }
    
    func asyncPatient(url: String) {
        /// Async Call
        hgService.asyncRequest(url: url) { data, status in
            DispatchQueue.main.async {
                if status ?? false {
                    if let _ = data as? String {
                        self.asyncPatient(url: url)
                    } else {
                        self.importPatient(entry: data as Any)
                    }
                } else {
                    self.isLoading = false
                    self.errorMessage = (data as? String) ?? ErrorMessage.error
                }
            }
        }
    }
    
    func importPatient(entry: Any) {
        /// Import Patient
        let params = ["resourceType": "Bundle", "id": "batch", "type": "batch", "entry": entry] as [String : Any]
        hgService.importPatient(body: params) { data, status in
            DispatchQueue.main.async {
                if status ?? false {
                    if let _ = data as? Bool {
                        self.markEnroll()
                    } else {
                        self.isLoading = false
                        self.errorMessage = (data as? String) ?? ErrorMessage.error
                    }
                } else {
                    self.isLoading = false
                    self.errorMessage = (data as? String) ?? ErrorMessage.error
                }
            }
        }
    }
    
    func markEnroll() {
        /// Mark Enroll true of patient
        hgService.markPatientEnroll(HGId: self.HGId ?? "") { data, status in
            if status ?? false {
                if let _ = data as? Bool {
                    self.isLoading = false
                    self.id = self.HGId
                } else {
                    self.isLoading = false
                    self.errorMessage = (data as? String) ?? ErrorMessage.error
                }
            } else {
                self.isLoading = false
                self.errorMessage = (data as? String) ?? ErrorMessage.error
            }
        }
    }
    
    func updateAppointmentStatus(appointmentId : Int, isApproved : Bool, reason: String, newDate: String, newStartTime: String, newEndTime: String, completion: @escaping (Bool?) -> Void) {
        self.isLoading = true
        let params = [Keys.appointment_id:appointmentId,Keys.is_approved:isApproved,Keys.reasonForDenial:reason,Keys.newDate:newDate,Keys.newStartTime:newStartTime,Keys.newEndTime:newEndTime] as [String:Any]
        service.updateAppointmentStatus(params: params) { (status) in
            self.isLoading = false
            DispatchQueue.main.async {
                if let status = status as? Bool {
                    completion(status)
                } else {
                    self.errorMessage = (status as? String) ?? ErrorMessage.error
                }
            }
        }
    }
    
    func getPDFUrl(docId: String) {
        self.isLoading = true
        hgService.getPDF(id: docId) { data in
            DispatchQueue.main.async {
                self.isLoading = true
                if let data = data as? [HGPDFModel] {
                    self.getPDF(url: data.first(where: {
                        $0.name == "url"
                    })?.valueString ?? "")
                } else {
                    self.isLoading = false
                    self.errorMessage = (data as? String) ?? ErrorMessage.error
                }
            }
        }
    }
    
    func getPDF(url: String) {
        self.isLoading = true
        let url = url.replacingOccurrences(of: Config.HG_BASE_URL, with: "").replacingOccurrences(of: Config.HG_BASE_API_URL, with: "")
        hgService.loadPDFHG(url: url) { data in
            DispatchQueue.main.async {
                self.isLoading = false
                if let data = data as? Data {
                    self.dataPDF = data
                } else {
                    self.errorMessage = (data as? String) ?? ErrorMessage.error
                }
            }
        }
    }
    
    func getLink(patId: Int, appId: Int, documents: String, physicianEmail: String, physicianId: Int, completion: @escaping (NSDictionary) -> Void) {
        self.isLoading = true
        let param = [Keys.patientId:"\(patId)",Keys.appointmentId:"\(appId)",Keys.physicianEmailId: physicianEmail, Keys.documentsName: documents, Keys.physicianId: "\(physicianId)"]
        service.getPreLink(params: param) { data in
            DispatchQueue.main.async {
                self.isLoading = false
                if let data = data as? NSDictionary {
                    completion(data)
                } else {
                    self.errorMessage = (data as? String) ?? ErrorMessage.error
                }
            }
        }
    }
    
    func updatePreOpStatus(patId: Int, appId: Int, preId: Int, mailBody: String, completion: @escaping (Any?) -> Void) {
        self.isLoading = true
        let param = [Keys.patientId:patId, Keys.appointmentId:appId, Keys.preopId: preId, Keys.mailBody: mailBody, Keys.sentBy: getUesrInfo()?.id ?? 0] as [String : Any]
        service.updatePreOpStatus(params: param) { data in
            DispatchQueue.main.async {
                self.isLoading = false
                completion(data)
                if let data = data as? String {
                    self.errorMessage = data
                }
            }
        }
    }
    
    func getPhysician(appId: Int) {
        self.isLoading = true
        let param = [Keys.appointment_Id: "\(appId)"]
        service.getPhysicianList(params: param) { data in
            DispatchQueue.main.async {
                self.isLoading = false
                if let data = data as? [TreatingPhysicianModel] {
                    self.physicianList = data.filter({ data in
                        return !(data.email ?? "").trimmingCharacters(in: .whitespaces).isEmpty
                    })
                    if self.physicianList?.count == 0 {
                        self.errorMessage = "No physician email available"
                    }
                } else {
                    if (data as? String) == MessagesConstant.dataNotFound {
                        self.physicianList = []
                        self.errorMessage = "No physician added"
                    } else {
                        self.errorMessage = (data as? String) ?? ErrorMessage.error
                    }
                }
            }
        }
    }
    
    func getRequestDraft(patientId: Int, appId: Int) {
        let param = [Keys.patient_Id: "\(patientId)", Keys.appointment_Id: "\(appId)"]
        self.isLoading = true
        service.getDraftDocs(params: param) { data, status in
            DispatchQueue.main.async {
                self.isLoading = false
                if status {
                    self.draftDocs = data as? String
                } else {
                    if (data as? String) != MessagesConstant.dataNotFound {
                        self.errorMessage = (data as? String) ?? ErrorMessage.error
                    }
                }
            }
        }
    }
    
    func updateDraft(patientId: Int, appId: Int, docs: String, completion: @escaping (Any?) -> Void) {
        let param = [Keys.patient_Id: "\(patientId)", Keys.appointment_Id: "\(appId)", Keys.documentsName: docs]
        service.updateDraftDocs(params: param) { data in
            DispatchQueue.main.async {
                self.isLoading = false
                if let data = data as? String {
                    self.errorMessage = data
                } else {
                    completion(data)
                }
            }
        }
    }
    
    func getSubmittedDocs(appId: Int, completion: @escaping(Any?) -> Void){
        let param = [Keys.appointmentId: String(appId)]
        service.getSubmittedDocs(params: param) { data in
            DispatchQueue.main.async {
                if let data = data as? [SubmittedDocumentsModel] {
                    self.submittedDocs = data
                    completion(data)
                } else {
                    self.submittedDocs?.removeAll()
                    completion(data)
                    if data as? String != MessagesConstant.dataNotFound {
                        self.errorMessage = (data as? String) ?? ErrorMessage.error
                    }
                }
            }
        }
    }
}
