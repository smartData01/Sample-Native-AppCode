//
//  SurgicalHistoryPatientModel.swift
//  MAPS
//
//  Created by shubhamfunde on 12/09/22.
//

import Foundation

public class SurgicalHistoryPatientModel {
    public var id : Int?
    public var patientId : Int?
    public var appointmentId : Int?
    public var pastSurgicalHistoryId : Int?
    public var surgicalName : String?
    public var isYes : Bool?
    public var isNo : Bool?
    public var isRight : String?
    public var isLeft : String?
    public var isBoth : String?
    public var dateValue : String?
    public var comments : String?
    public var input1Value : String?
    public var input2Value : String?
    public var detail: String?

    public class func modelsFromDictionaryArray(array:NSArray) -> [SurgicalHistoryPatientModel]
    {
        var models:[SurgicalHistoryPatientModel] = []
        for item in array
        {
            models.append(SurgicalHistoryPatientModel(dictionary: item as! NSDictionary)!)
        }
        return models
    }

    required public init?(dictionary: NSDictionary) {

        id = dictionary["id"] as? Int
        patientId = dictionary["patientId"] as? Int
        appointmentId = dictionary["appointmentId"] as? Int
        pastSurgicalHistoryId = dictionary["pastSurgicalHistoryId"] as? Int
        surgicalName = dictionary["surgicalName"] as? String
        isYes = dictionary["isYes"] as? Bool
        isNo = dictionary["isNo"] as? Bool
        isRight = dictionary["isRight"] as? String
        isLeft = dictionary["isLeft"] as? String
        isBoth = dictionary["isBoth"] as? String
        dateValue = dictionary["dateValue"] as? String
        comments = dictionary["comments"] as? String
        input1Value = dictionary["input1Value"] as? String
        input2Value = dictionary["input2Value"] as? String
        detail = dictionary["detail"] as? String
    }

    public func dictionaryRepresentation() -> NSDictionary {

        let dictionary = NSMutableDictionary()

        dictionary.setValue(self.id, forKey: "id")
        dictionary.setValue(self.patientId, forKey: "patientId")
        dictionary.setValue(self.appointmentId, forKey: "appointmentId")
        dictionary.setValue(self.pastSurgicalHistoryId, forKey: "pastSurgicalHistoryId")
        dictionary.setValue(self.surgicalName, forKey: "surgicalName")
        dictionary.setValue(self.isYes, forKey: "isYes")
        dictionary.setValue(self.isNo, forKey: "isNo")
        dictionary.setValue(self.isRight, forKey: "isRight")
        dictionary.setValue(self.isLeft, forKey: "isLeft")
        dictionary.setValue(self.isBoth, forKey: "isBoth")
        dictionary.setValue(self.dateValue, forKey: "dateValue")
        dictionary.setValue(self.comments, forKey: "comments")
        dictionary.setValue(self.input1Value, forKey: "input1Value")
        dictionary.setValue(self.input2Value, forKey: "input2Value")
        dictionary.setValue(self.detail, forKey: "detail")

        return dictionary
    }

}
