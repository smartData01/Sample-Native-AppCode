//
//  MedicationPatientModel.swift
//  MAPS
//
//  Created by shubhamfunde on 15/09/22.
//

import Foundation

public class MedicationPatientModel {
    public var patientMedicationId : Int?
    public var medicationName : String?
    public var detail : String?

    public class func modelsFromDictionaryArray(array:NSArray) -> [MedicationPatientModel]
    {
        var models:[MedicationPatientModel] = []
        for item in array
        {
            models.append(MedicationPatientModel(dictionary: item as! NSDictionary)!)
        }
        return models
    }

    required public init?(dictionary: NSDictionary) {

        patientMedicationId = dictionary["patientMedicationId"] as? Int
        medicationName = dictionary["medicationName"] as? String
        detail = dictionary["detail"] as? String
    }

    public func dictionaryRepresentation() -> NSDictionary {

        let dictionary = NSMutableDictionary()

        dictionary.setValue(self.patientMedicationId, forKey: "patientMedicationId")
        dictionary.setValue(self.medicationName, forKey: "medicationName")
        dictionary.setValue(self.detail, forKey: "detail")

        return dictionary
    }
}
