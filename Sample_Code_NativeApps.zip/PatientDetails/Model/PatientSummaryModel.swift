//
//  PatientSummaryModel.swift
//  MAPS
//
//  Created by shubhamfunde on 29/09/22.
//

import Foundation

public class PatientSummaryModel {
    public var id : Int?
    public var questionName : String?
    public var isYes : Int?
    public var isNo : Int?

    public class func modelsFromDictionaryArray(array:NSArray) -> [PatientSummaryModel]
    {
        var models:[PatientSummaryModel] = []
        for item in array
        {
            models.append(PatientSummaryModel(dictionary: item as! NSDictionary)!)
        }
        return models
    }

    required public init?(dictionary: NSDictionary) {

        id = dictionary["id"] as? Int
        questionName = dictionary["questionName"] as? String
        isYes = dictionary["isYes"] as? Int
        isNo = dictionary["isNo"] as? Int
    }

    public func dictionaryRepresentation() -> NSDictionary {

        let dictionary = NSMutableDictionary()

        dictionary.setValue(self.id, forKey: "id")
        dictionary.setValue(self.questionName, forKey: "questionName")
        dictionary.setValue(self.isYes, forKey: "isYes")
        dictionary.setValue(self.isNo, forKey: "isNo")

        return dictionary
    }
}
