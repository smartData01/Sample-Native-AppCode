//
//  PatientDetailsModel.swift
//  MAPS
//
//  Created by shubhamfunde on 01/09/22.
//

import Foundation

public class PatientDetailsModel {
    public var patient_id : Int?
    public var users_id : Int?
    public var firstname : String?
    public var lastname : String?
    public var dob : String?
    public var email : String?
    public var stripe_customer_id : String?
    public var stripe_bank_id : String?
    public var stripe_card_id : String?
    public var time_zone_master_id : String?
    public var address1 : String?
    public var address2 : String?
    public var city : String?
    public var state : String?
    public var zipcode : String?
    public var contactno : String?
    public var height : String?
    public var weight : String?
    public var booldgroup : String?
    public var photo : String?
    public var imageName : String?
    public var imagePath : String?
    public var created_date : String?
    public var is_active : String?
    public var is_staff : String?
    public var clinicId : Int?
    public var gender : String?
    public var ssn : String?
    public var country : String?
    public var guardianName : String?
    public var guardianrelation : String?
    public var guardiancontactno : String?
    public var guardianaddress : String?
    public var surrogatename : String?
    public var surrogatecontactno : String?
    public var caretakername : String?
    public var caretakerrelationship : String?
    public var caretakercontactno : String?
    public var emergencycontactname : String?
    public var emergencycontactrelationship : String?
    public var emergencycontactno : String?
    public var emergencycontactaddress : String?
    public var isProfileUpdated : Bool?
    public var imageURL : String?
    public var hgId : String?
    public var treating_Physician : Array<TreatingPhysicianModel>?
    public var concent_Form : Array<ConsentFormModel>?
    public var patientWeightInKg : String?
    public var patientWeightInLbs : String?
    public var patientHeightInCm : String?
    public var patientHeightFeet : Int?
    public var patientHeightInch : Int?
    public var anesthesiologistClinicASA : Array<ASAModel>?
    public var asa : Int?
    public var asA_Value : Int?
    public var isPatientCleared : Bool?
    public var isDraftSaved : Bool?
    public var status : Int?
    public var appointment_Date : String?
    public var appointment_From : String?
    public var appointment_To : String?
    public var completeProcedure : Bool?
    public var initiatePayment : Bool?
    public var mR_Number : String?
    public var pharmacyId : Int?
    public var surgeryName : String?

    public class func modelsFromDictionaryArray(array:NSArray) -> [PatientDetailsModel]
    {
        var models:[PatientDetailsModel] = []
        for item in array
        {
            models.append(PatientDetailsModel(dictionary: item as! NSDictionary)!)
        }
        return models
    }

    required public init?(dictionary: NSDictionary) {

        patient_id = dictionary["patient_id"] as? Int
        users_id = dictionary["users_id"] as? Int
        firstname = dictionary["firstname"] as? String
        lastname = dictionary["lastname"] as? String
        dob = dictionary["dob"] as? String
        email = dictionary["email"] as? String
        stripe_customer_id = dictionary["stripe_customer_id"] as? String
        stripe_bank_id = dictionary["stripe_bank_id"] as? String
        stripe_card_id = dictionary["stripe_card_id"] as? String
        time_zone_master_id = dictionary["time_zone_master_id"] as? String
        address1 = dictionary["address1"] as? String
        address2 = dictionary["address2"] as? String
        city = dictionary["city"] as? String
        state = dictionary["state"] as? String
        zipcode = dictionary["zipcode"] as? String
        contactno = dictionary["contactno"] as? String
        height = dictionary["height"] as? String
        weight = dictionary["weight"] as? String
        booldgroup = dictionary["booldgroup"] as? String
        photo = dictionary["photo"] as? String
        imageName = dictionary["imageName"] as? String
        imagePath = dictionary["imagePath"] as? String
        created_date = dictionary["created_date"] as? String
        is_active = dictionary["is_active"] as? String
        is_staff = dictionary["is_staff"] as? String
        clinicId = dictionary["clinicId"] as? Int
        gender = dictionary["gender"] as? String
        ssn = dictionary["ssn"] as? String
        country = dictionary["country"] as? String
        guardianName = dictionary["guardianName"] as? String
        guardianrelation = dictionary["guardianrelation"] as? String
        guardiancontactno = dictionary["guardiancontactno"] as? String
        guardianaddress = dictionary["guardianaddress"] as? String
        surrogatename = dictionary["surrogatename"] as? String
        surrogatecontactno = dictionary["surrogatecontactno"] as? String
        caretakername = dictionary["caretakername"] as? String
        caretakerrelationship = dictionary["caretakerrelationship"] as? String
        caretakercontactno = dictionary["caretakercontactno"] as? String
        emergencycontactname = dictionary["emergencycontactname"] as? String
        emergencycontactrelationship = dictionary["emergencycontactrelationship"] as? String
        emergencycontactno = dictionary["emergencycontactno"] as? String
        emergencycontactaddress = dictionary["emergencycontactaddress"] as? String
        isProfileUpdated = dictionary["isProfileUpdated"] as? Bool
        imageURL = dictionary["imageURL"] as? String
        hgId = dictionary["hgId"] as? String
        if dictionary["treating_Physician"] != nil {
            treating_Physician = TreatingPhysicianModel.modelsFromDictionaryArray(array: dictionary["treating_Physician"] as! NSArray)
        }
        if dictionary["concent_Form"] != nil {
            concent_Form = ConsentFormModel.modelsFromDictionaryArray(array: dictionary["concent_Form"] as! NSArray)
        }
        patientWeightInKg = dictionary["patientWeightInKg"] as? String
        patientWeightInLbs = dictionary["patientWeightInLbs"] as? String
        patientHeightInCm = dictionary["patientHeightInCm"] as? String
        patientHeightFeet = dictionary["patientHeightFeet"] as? Int
        patientHeightInch = dictionary["patientHeightInch"] as? Int
        if (dictionary["anesthesiologistClinicASA"] != nil) { anesthesiologistClinicASA = ASAModel.modelsFromDictionaryArray(array: dictionary["anesthesiologistClinicASA"] as! NSArray) }
        asa = dictionary["asa"] as? Int
        asA_Value = dictionary["asA_Value"] as? Int
        isPatientCleared = dictionary["isPatientCleared"] as? Bool
        isDraftSaved = dictionary["isDraftSaved"] as? Bool
        status = dictionary[TitleConstant.status] as? Int
        appointment_Date = dictionary["appointment_Date"] as? String
        appointment_From = dictionary["appointment_From"] as? String
        appointment_To = dictionary["appointment_To"] as? String
        completeProcedure = dictionary["completeProcedure"] as? Bool
        initiatePayment = dictionary["initiatePayment"] as? Bool
        mR_Number = dictionary["mR_Number"] as? String
        pharmacyId = dictionary["pharmacyId"] as? Int
        surgeryName = dictionary["surgeryName"] as? String
    }

        
/**
    Returns the dictionary representation for the current instance.
    
    - returns: NSDictionary.
*/
    public func dictionaryRepresentation() -> NSDictionary {

        let dictionary = NSMutableDictionary()

        dictionary.setValue(self.patient_id, forKey: "patient_id")
        dictionary.setValue(self.users_id, forKey: "users_id")
        dictionary.setValue(self.firstname, forKey: "firstname")
        dictionary.setValue(self.lastname, forKey: "lastname")
        dictionary.setValue(self.dob, forKey: "dob")
        dictionary.setValue(self.email, forKey: "email")
        dictionary.setValue(self.stripe_customer_id, forKey: "stripe_customer_id")
        dictionary.setValue(self.stripe_bank_id, forKey: "stripe_bank_id")
        dictionary.setValue(self.stripe_card_id, forKey: "stripe_card_id")
        dictionary.setValue(self.time_zone_master_id, forKey: "time_zone_master_id")
        dictionary.setValue(self.address1, forKey: "address1")
        dictionary.setValue(self.address2, forKey: "address2")
        dictionary.setValue(self.city, forKey: "city")
        dictionary.setValue(self.state, forKey: "state")
        dictionary.setValue(self.zipcode, forKey: "zipcode")
        dictionary.setValue(self.contactno, forKey: "contactno")
        dictionary.setValue(self.height, forKey: "height")
        dictionary.setValue(self.weight, forKey: "weight")
        dictionary.setValue(self.booldgroup, forKey: "booldgroup")
        dictionary.setValue(self.photo, forKey: "photo")
        dictionary.setValue(self.imageName, forKey: "imageName")
        dictionary.setValue(self.imagePath, forKey: "imagePath")
        dictionary.setValue(self.created_date, forKey: "created_date")
        dictionary.setValue(self.is_active, forKey: "is_active")
        dictionary.setValue(self.is_staff, forKey: "is_staff")
        dictionary.setValue(self.clinicId, forKey: "clinicId")
        dictionary.setValue(self.gender, forKey: "gender")
        dictionary.setValue(self.ssn, forKey: "ssn")
        dictionary.setValue(self.country, forKey: "country")
        dictionary.setValue(self.guardianName, forKey: "guardianName")
        dictionary.setValue(self.guardianrelation, forKey: "guardianrelation")
        dictionary.setValue(self.guardiancontactno, forKey: "guardiancontactno")
        dictionary.setValue(self.guardianaddress, forKey: "guardianaddress")
        dictionary.setValue(self.surrogatename, forKey: "surrogatename")
        dictionary.setValue(self.surrogatecontactno, forKey: "surrogatecontactno")
        dictionary.setValue(self.caretakername, forKey: "caretakername")
        dictionary.setValue(self.caretakerrelationship, forKey: "caretakerrelationship")
        dictionary.setValue(self.caretakercontactno, forKey: "caretakercontactno")
        dictionary.setValue(self.emergencycontactname, forKey: "emergencycontactname")
        dictionary.setValue(self.emergencycontactrelationship, forKey: "emergencycontactrelationship")
        dictionary.setValue(self.emergencycontactno, forKey: "emergencycontactno")
        dictionary.setValue(self.emergencycontactaddress, forKey: "emergencycontactaddress")
        dictionary.setValue(self.isProfileUpdated, forKey: "isProfileUpdated")
        dictionary.setValue(self.imageURL, forKey: "imageURL")
        dictionary.setValue(self.hgId, forKey: "hgId")
        dictionary.setValue(self.completeProcedure, forKey: "completeProcedure")
        dictionary.setValue(self.initiatePayment, forKey: "initiatePayment")
        dictionary.setValue(self.mR_Number, forKey: "mR_Number")
        dictionary.setValue(self.pharmacyId, forKey: "pharmacyId")
        dictionary.setValue(self.surgeryName, forKey: "surgeryName")
        return dictionary
    }

}
