//
//  ConsentFormModel.swift
//  MAPS
//
//  Created by shubhamfunde on 08/09/22.
//

import Foundation

public class ConsentFormModel {
    public var concentFormId : Int?
    public var formName : String?
    public var formUrl : String?
    public var isSubmitted : Bool?
    public var isApproved : Bool?

    public class func modelsFromDictionaryArray(array:NSArray) -> [ConsentFormModel]
    {
        var models:[ConsentFormModel] = []
        for item in array
        {
            models.append(ConsentFormModel(dictionary: item as! NSDictionary)!)
        }
        return models
    }

    required public init?(dictionary: NSDictionary) {
        concentFormId = dictionary["concentFormId"] as? Int
        formName = dictionary["formName"] as? String
        formUrl = dictionary["formUrl"] as? String
        isSubmitted = dictionary["isSubmitted"] as? Bool
        isApproved = dictionary["isApproved"] as? Bool
    }

    public func dictionaryRepresentation() -> NSDictionary {

        let dictionary = NSMutableDictionary()

        dictionary.setValue(self.concentFormId, forKey: "concentFormId")
        dictionary.setValue(self.formName, forKey: "formName")
        dictionary.setValue(self.formUrl, forKey: "formUrl")
        dictionary.setValue(self.isSubmitted, forKey: "isSubmitted")
        dictionary.setValue(self.isApproved, forKey: "isApproved")

        return dictionary
    }
}
