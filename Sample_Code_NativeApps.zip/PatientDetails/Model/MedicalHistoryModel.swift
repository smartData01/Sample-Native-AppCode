//
//  MedicalHistorymodel.swift
//  MAPS
//
//  Created by shubhamfunde on 12/09/22.
//

import Foundation

public class MedicalHistoryModel {
    public var id : Int?
    public var patientId : Int?
    public var appointmentId : Int?
    public var pastMedicalHistoryId : Int?
    public var medicalName : String?
    public var isRight : Bool?
    public var isLeft : Bool?
    public var isBoth : Bool?
    public var dateValue : String?
    public var comments : String?
    public var input1Value : String?
    public var input2Value : String?
    public var isSelected : Bool?
    public var detail : String?

    public class func modelsFromDictionaryArray(array:NSArray) -> [MedicalHistoryModel]
    {
        var models:[MedicalHistoryModel] = []
        for item in array
        {
            models.append(MedicalHistoryModel(dictionary: item as! NSDictionary)!)
        }
        return models
    }

    required public init?(dictionary: NSDictionary) {

        id = dictionary["id"] as? Int
        patientId = dictionary["patientId"] as? Int
        appointmentId = dictionary["appointmentId"] as? Int
        pastMedicalHistoryId = dictionary["pastMedicalHistoryId"] as? Int
        medicalName = dictionary["medicalName"] as? String
        isRight = dictionary["isRight"] as? Bool
        isLeft = dictionary["isLeft"] as? Bool
        isBoth = dictionary["isBoth"] as? Bool
        dateValue = dictionary["dateValue"] as? String
        comments = dictionary["comments"] as? String
        input1Value = dictionary["input1Value"] as? String
        input2Value = dictionary["input2Value"] as? String
        isSelected = dictionary["isSelected"] as? Bool
        detail = dictionary["detail"] as? String
    }

    public func dictionaryRepresentation() -> NSDictionary {

        let dictionary = NSMutableDictionary()

        dictionary.setValue(self.id, forKey: "id")
        dictionary.setValue(self.patientId, forKey: "patientId")
        dictionary.setValue(self.appointmentId, forKey: "appointmentId")
        dictionary.setValue(self.pastMedicalHistoryId, forKey: "pastMedicalHistoryId")
        dictionary.setValue(self.medicalName, forKey: "medicalName")
        dictionary.setValue(self.isRight, forKey: "isRight")
        dictionary.setValue(self.isLeft, forKey: "isLeft")
        dictionary.setValue(self.isBoth, forKey: "isBoth")
        dictionary.setValue(self.dateValue, forKey: "dateValue")
        dictionary.setValue(self.comments, forKey: "comments")
        dictionary.setValue(self.input1Value, forKey: "input1Value")
        dictionary.setValue(self.input2Value, forKey: "input2Value")
        dictionary.setValue(self.isSelected, forKey: "isSelected")
        dictionary.setValue(self.detail, forKey: "detail")

        return dictionary
    }
}
