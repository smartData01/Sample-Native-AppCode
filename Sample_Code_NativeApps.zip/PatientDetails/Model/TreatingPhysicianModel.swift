//
//  TreatingPhysicianModel.swift
//  MAPS
//
//  Created by shubhamfunde on 06/09/22.
//

import Foundation

public class TreatingPhysicianModel {
    public var treatingPhysicianId : Int?
    public var patientId : Int?
    public var physicianName : String?
    public var contactNo : String?
    public var email : String?
    public var state : String?
    public var city : String?
    public var speciality : String?


    public class func modelsFromDictionaryArray(array:NSArray) -> [TreatingPhysicianModel]
    {
        var models:[TreatingPhysicianModel] = []
        for item in array
        {
            models.append(TreatingPhysicianModel(dictionary: item as! NSDictionary)!)
        }
        return models
    }

    required public init?(dictionary: NSDictionary) {

        treatingPhysicianId = dictionary["treatingPhysicianId"] as? Int
        patientId = dictionary["patientId"] as? Int
        physicianName = dictionary["physicianName"] as? String
        contactNo = dictionary["contactNo"] as? String
        email = dictionary["email"] as? String
        state = dictionary["state"] as? String
        city = dictionary["city"] as? String
        speciality = dictionary["speciality"] as? String
    }

    public func dictionaryRepresentation() -> NSDictionary {

        let dictionary = NSMutableDictionary()

        dictionary.setValue(self.treatingPhysicianId, forKey: "treatingPhysicianId")
        dictionary.setValue(self.patientId, forKey: "patientId")
        dictionary.setValue(self.physicianName, forKey: "physicianName")
        dictionary.setValue(self.contactNo, forKey: "contactNo")
        dictionary.setValue(self.email, forKey: "email")
        dictionary.setValue(self.state, forKey: "state")
        dictionary.setValue(self.city, forKey: "city")
        dictionary.setValue(self.speciality, forKey: "speciality")

        return dictionary
    }

}
