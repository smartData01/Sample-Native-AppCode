//
//  AllergiesPatientModel.swift
//  MAPS
//
//  Created by shubhamfunde on 12/09/22.
//

import Foundation

public class AllergiesPatientModel {
    public var id : Int?
    public var patientId : Int?
    public var appointmentId : Int?
    public var allergyMasterId : Int?
    public var allergyName : String?
    public var isYes : Bool?
    public var isNo : Bool?
    public var isSelected : Bool?

    public class func modelsFromDictionaryArray(array:NSArray) -> [AllergiesPatientModel]
    {
        var models:[AllergiesPatientModel] = []
        for item in array
        {
            models.append(AllergiesPatientModel(dictionary: item as! NSDictionary)!)
        }
        return models
    }

    required public init?(dictionary: NSDictionary) {

        id = dictionary["id"] as? Int
        patientId = dictionary["patientId"] as? Int
        appointmentId = dictionary["appointmentId"] as? Int
        allergyMasterId = dictionary["allergyMasterId"] as? Int
        allergyName = dictionary["allergyName"] as? String
        isYes = dictionary["isYes"] as? Bool
        isNo = dictionary["isNo"] as? Bool
        isSelected = dictionary["isSelected"] as? Bool
    }

    public func dictionaryRepresentation() -> NSDictionary {

        let dictionary = NSMutableDictionary()

        dictionary.setValue(self.id, forKey: "id")
        dictionary.setValue(self.patientId, forKey: "patientId")
        dictionary.setValue(self.appointmentId, forKey: "appointmentId")
        dictionary.setValue(self.allergyMasterId, forKey: "allergyMasterId")
        dictionary.setValue(self.allergyName, forKey: "allergyName")
        dictionary.setValue(self.isYes, forKey: "isYes")
        dictionary.setValue(self.isNo, forKey: "isNo")
        dictionary.setValue(self.isSelected, forKey: "isSelected")

        return dictionary
    }
}
